package com.ars.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.exception.AirlineException;
import com.ars.service.AirlineServiceImpl;
import com.ars.service.IAirlineService;

/**
 * Servlet implementation class AirlineController
 */
@WebServlet("/AirlineController")
public class AirlineController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       private static int bcou=0;
       private static int fcou=0;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AirlineController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	String option=request.getParameter("action");
	String userName,password,flightNo ;
	Users user=null;
	FlightInformation flightInfo=null;
	IAirlineService is=new AirlineServiceImpl();                        //is.verifyUser(uName,password)
	switch(option)
	{
	case "register":
			userName=request.getParameter("");
	case "login":
		userName=request.getParameter("userName");
		password=request.getParameter("password");
		user=new Users();
		try {
			if(is.verifyUser(userName,password))
			{
				user.setuName(userName);
				user.setPassword(password);
				if(is.getRole(user).equals("user"))
				{
					getServletContext().getRequestDispatcher("/userPage.jsp").forward(request, response);
				}
				else if(is.getRole(user).equals("admin"))
				
				{
					getServletContext().getRequestDispatcher("/AdminPage.jsp").forward(request, response);
				}
				else if(is.getRole(user).equals("executive"))
					
				{
					
					getServletContext().getRequestDispatcher("/ExecutivePage.jsp").forward(request, response);

				}
				
			}
			else
			{
				getServletContext().getRequestDispatcher("/Login.jsp").forward(request, response);
			}
		} catch (AirlineException e) {
			
			System.out.println("Please enter valid credentials");
		}
		
	case "FlightInfo":
		List<FlightInformation> flightList;
		String src = request.getParameter("sourceCity");
		String des = request.getParameter("destinationCity");
		flightInfo = new FlightInformation();
		flightInfo.setArrCity(des);
		flightInfo.setDepCity(src);
		//is.getFlightInfo(flightinfo)
		try {
			flightList=is.getFlightInfo(flightInfo);
			request.setAttribute("flightList", flightList);
			getServletContext().getRequestDispatcher("/FlightInfoPage.jsp").forward(request, response);
			
		} catch (AirlineException e) 
		{


			e.printStackTrace();
		}
		
		
	case "submit":
		flightNo= request.getParameter("flight");
		try {
			System.out.println("hello");
			FlightInformation flightDet=is.getFlightDetails(flightNo);
			request.setAttribute("flightDetails", flightDet);
			HttpSession session=request.getSession();
			session.setAttribute("flightDetails", flightDet);
			getServletContext().getRequestDispatcher("/BookTickets.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	case "booknow":
		String email=request.getParameter("email");
		String classType=request.getParameter("classType");
		int noofPassengers=Integer.parseInt(request.getParameter("no.ofTickets"));
		String creditCardInfo=request.getParameter("creditcard");
		BookingInformation book=new BookingInformation();
		HttpSession session=request.getSession(false);
		FlightInformation flight=(FlightInformation) session.getAttribute("flightDetails");
		book.setFlightNo(flight.getFlightNo());
		book.setDepCity(flight.getDepCity());
		book.setArrCity(flight.getArrCity());
		book.setCustEmail(email);
		book.setCreditCardInfo(creditCardInfo);
		book.setNoOfPassengers(noofPassengers);
		if(classType.equals("bussinessclass"))
		{
			book.setClassType("Bussiness");
			if(noofPassengers<=flight.getBussAvail())
			{
				book.setTotalFare(noofPassengers*flight.getBussSeatsFare());
			/*System.out.println(book.getTotalFare()+"seatFare");*/
				StringBuffer seatNum=new StringBuffer();
				for(int i=0;i<noofPassengers;i++)
				{
					seatNum.append("BT");
					seatNum.append(++bcou);
					int j=i;
					if(++j<noofPassengers)
						seatNum.append(",");
				}
				book.setSeatNumbers(seatNum);
			}
		}
		else
		{
			book.setClassType("First");
			/*book.setClassType("Bussiness");*/
			if(noofPassengers<=flight.getBussAvail())
			{
			book.setTotalFare(noofPassengers*flight.getFirstSeatFare());
			/*System.out.println(book.getTotalFare()+"seatFare"+flightinfo.getFirstSeatFare());*/
			StringBuffer seatNum=new StringBuffer();
			for(int i=0;i<noofPassengers;i++)
			{
				seatNum.append("FT");
				seatNum.append(++fcou);
				int j=i;
				if(++j<noofPassengers)
				seatNum.append(",");
			}
			book.setSeatNumbers(seatNum);
			}
		}
		book.setNoOfPassengers(noofPassengers);
		int booking;
		try {
			booking = is.bookTicket(book);
			System.out.println("Your booking id:"+booking);
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	
		
	}
	
	
	}

}
