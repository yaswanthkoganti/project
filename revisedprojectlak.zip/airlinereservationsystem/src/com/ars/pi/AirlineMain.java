package com.ars.pi;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.sql.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.dao.AirlineDaoImpl;
import com.ars.dao.IAirlineDao;
import com.ars.exception.AirlineException;
import com.ars.service.AirlineServiceImpl;
import com.ars.service.IAirlineService;

public class AirlineMain {

	public static void main(String[] args) throws ParseException {
			int choice,coun=0;
			String uName,password,email,pass;
			IAirlineService is=new AirlineServiceImpl();
			Users user=null;
			try{
			Scanner scan=new Scanner(System.in);
			System.out.println("Choose from below options:");
			System.out.println("1.Register\n2.Login");
			choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Please enter the details to complete registration:");
				do{
				System.out.println("UserName:");
				 uName=scan.next();
				}
				while(is.isValidName(uName));
				do{
				System.out.println("Password:");
				password=scan.next();
				}while(is.isValidPassword(password));
				do{
				System.out.println("E-mail:");
				email=scan.next();
				}while(is.isValidEmail(email));
				user=new Users();
				user.setRole("user");
				user.setuName(uName);
				user.setPassword(password);
				user.setEmail(email);
				is.addUserDetails(user);
				break;
			case 2:
				System.out.println("Please enter your login credentials:");
				do{
					user=new Users();
					//admin=new Users();
					System.out.println("UserName:");
					uName=scan.next();
					System.out.println("Password:");
					password=scan.next();
					coun++;
					if(coun==3)
					{
						System.out.println("You Need to Reset your password.");
						System.out.println("Enter your email ID");
						email=scan.next();
						System.out.println("Enter new password to login");
						pass=scan.next();
						is.isValidPassword(pass);
						is.updatePassword(email,pass);
						coun=0;
					}	
				}while(is.verifyUser(uName,password));
				user.setuName(uName);
				user.setPassword(password);
			
				if(is.getRole(user).equals("user"))
					getAirlines(user);	
				else if(is.getRole(user).equals("admin"))
				System.out.println("Dear admin, these are the actions you can perform");
				System.out.println("1 Add Flights\n");
				System.out.println("2 Delete Flights\n");
				System.out.println("3 Update Flight schedules\n");
				System.out.println("4 Generating  ");
				int ch;
				FlightInformation flight=null;
				ch=scan.nextInt();
				if(ch==1)
				{
					System.out.println("Here we go to add a flight's details...");
					System.out.println("Enter flight number to be added into flight list: ");
					String fnum;
					fnum=scan.next();
					//System.out.println(fnum);
					System.out.println("Enter the airlines to which the flight belongs to");
					String fairline;
					fairline=scan.next();
					System.out.println("Enter the departure city");
					String fdeptcity;
					fdeptcity=scan.next();
					System.out.println("Enter the arrival city");
					String farrivalcity;
					farrivalcity=scan.next();
					System.out.println("Enter the departure date(dd/mm/yyyy)");
					String fdepdate;
					fdepdate=scan.next();
					java.util.Date d1=new SimpleDateFormat("dd/MM/yyyy").parse(fdepdate);
					Date date1=new Date(d1.getDate());
					System.out.println("Enter the arrival date(dd/mm/yyyy)");
					String farrdate;
					
					farrdate=scan.next();
					java.util.Date d2=new SimpleDateFormat("dd/MM/yyyy").parse(farrdate);
					Date date2=new Date(d2.getDate());
					System.out.println("Enter the departure time");
					String fdeptime;
					fdeptime=scan.next();
					System.out.println("Enter the arrival time");
					String farrtime;
					farrtime=scan.next();
					System.out.println("Enter the no of first class seats in the flight");
					int ffirst;
					ffirst=scan.nextInt();
					System.out.println("Enter the first class seats fare");
					int ffirstfare;
					ffirstfare=scan.nextInt();
					System.out.println("Enter the business class seats in the flight");
					int fbuss;
					fbuss=scan.nextInt();
					System.out.println("Enter the bussiness class seats fare");
					int fbussfare;
					fbussfare=scan.nextInt();
					System.out.println("Your insertion of flight is successful");
					
					
					flight=new FlightInformation();
					flight.setFlightNo(fnum);
					System.out.println(flight.getFlightNo());
					flight.setAirline(fairline);
				    flight.setDepCity(fdeptcity);
					flight.setArrCity(farrivalcity);
					flight.setDepDate(date1);
					flight.setArrDate(date2);
					flight.setArrTime(farrtime);
					flight.setDepTime(fdeptime);
					flight.setFirstSeats(ffirst);
					flight.setFirstSeatFare(ffirstfare);
					flight.setBussSeats(fbuss);
					flight.setBussSeatsFare(fbussfare);
					
					IAirlineService add=new AirlineServiceImpl();
					add.addFlight(flight);
					
				    
					
				}
				else if(ch==2)
				{
					System.out.println("Here we go to delete a flight's details");
					System.out.println("Enter the flight number to get deleted from the flight list");
					String fnum;
					fnum=scan.next();
					flight=new FlightInformation();
					flight.setFlightNo(fnum);
					
					IAirlineService del=new AirlineServiceImpl();
					
					if(del.isValidFlightNum(fnum)==1)
					{
						
						if(del.deleteFlight(flight)==1)
						{
							
							System.out.println("Your deletion was successful");	
						}
						else
						{ 
							
							System.out.println("Here we go to update a flight's schedules");
						}
						
						
						
					}
					
						
					}
				else if(ch==3)
				{
					
				}
				
			}
			}
			catch(AirlineException ae)
			{
				System.out.println("hello");
				System.err.println("Error Occured"+ae.getMessage());
				main(args);
			}
			
	}



	private static void getAirlines(Users user) throws AirlineException {
		Scanner scan=new Scanner(System.in);
		int choice;
		List<FlightInformation> airList;
		System.out.println("Welcome to Capgemini Airlines");
		System.out.println("Please choose from below options:");
		System.out.println("1)Book Ticket\n2)View Ticket Info\n3)Cancel Booking");
		choice=scan.nextInt();
		switch(choice)
		{
		case 1:
		System.out.println("Please Enter your Source city:");
		String depCity=scan.next();
		System.out.println("Please Enter your destination city:");
		String arrCity=scan.next();
		IAirlineService is=new AirlineServiceImpl();
		FlightInformation flightinfo= new FlightInformation();
		flightinfo.setDepCity(depCity);
		flightinfo.setArrCity(arrCity);
		airList=is.getFlightInfo(flightinfo);
		if (airList != null) {
			Iterator<FlightInformation> i = airList.iterator();
			while (i.hasNext()) {
				System.out.println(i.next());
			}
		}
		System.out.println("Enter flightno to book ticket");
		String flightNum=scan.next();
		System.out.println("Choose the class type from the following:");
		System.out.println("1)Bussiness Class 2)First Class");
		int type=scan.nextInt();
		System.out.println("Enter no of tickets:");
		int noofTickets=scan.nextInt();
		BookingInformation bookInfo=new BookingInformation();
		if(type==1)
			bookInfo.setClassType("Bussiness");
		else
			bookInfo.setClassType("First");;
		bookInfo.setNoOfPassengers(noofTickets);
		is.bookTicket(bookInfo);
		
		}
		
	}

}
