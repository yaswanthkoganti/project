package com.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.exception.AirlineException;
import com.ars.util.DBConnection;

public class AirlineDaoImpl implements IAirlineDao {

	@Override
	public boolean verifyUser(String uName, String password) throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try{
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.VALIDATEUSER);
			pst.setString(1,uName);
			pst.setString(2,password);
			rs=pst.executeQuery();
			rs.next();
			if(rs.getInt(1)>0)
			{
				return false;
			}
			else
				return true;
		}
		catch(SQLException se)
		{
			throw new AirlineException("Database Connection Problem.");
		}
		finally
		{
			try{
				rs.close();
				pst.close();
				conn.close();
			}
			catch(SQLException se)
			{
				throw new AirlineException("Database Connection closing Problem.");
			}
		}
	}

	@Override
	public void addUserDetails(Users user) throws AirlineException {
		Connection conn;
		try {
			conn = DBConnection.getInstance().getConnection();
		java.sql.Statement statement=conn.createStatement();
		ResultSet result=null;
		PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.INSERTQUERY);
		preparedStatement.setString(1,user.getuName());
		preparedStatement.setString(2,user.getPassword());
		preparedStatement.setString(3,user.getRole());
		preparedStatement.setString(4,user.getEmail());
		preparedStatement.executeQuery();
		} catch (SQLException e) {
			throw new AirlineException("DB Connetcion Problem");
		}
		
	}
	public String getRole(Users user) throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try{
			conn=DBConnection.getInstance().getConnection();
	pst=conn.prepareStatement(IQueryMapper.GETROLE);
	pst.setString(1,user.getuName());
	pst.setString(2,user.getPassword());
	rs=pst.executeQuery();
	rs.next();
	return rs.getString(1);
}	catch(SQLException se)
		{
	throw new AirlineException("Database Connection closing Problem.");
}
		
	}

	@Override
	public List<FlightInformation> getFlightInfo(FlightInformation fligh) throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<FlightInformation> airList=null;
		int count=0;
		try{
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.GETFLIGHTINFO);
			pst.setString(1,fligh.getDepCity());
			pst.setString(2,fligh.getArrCity());
			rs=pst.executeQuery();
			airList=new ArrayList<FlightInformation>();
			while(rs.next())
			{
				FlightInformation flight=new FlightInformation();
				flight.setFlightNo(rs.getString(1));
				flight.setAirline(rs.getString(2));
				flight.setDepCity(rs.getString(3));
				flight.setArrCity(rs.getString(4));
				flight.setDepDate(rs.getDate(5));
				flight.setArrDate(rs.getDate(6));
				flight.setDepTime(rs.getString(7));
				flight.setArrTime(rs.getString(8));
				flight.setFirstSeats(rs.getInt(9));
				flight.setFirstSeatFare(rs.getDouble(10));
				flight.setBussSeats(rs.getInt(11));
				flight.setBussSeatsFare(rs.getDouble(12));
				flight.setFirstAvail(rs.getInt(13));
				flight.setBussAvail(rs.getInt(14));
				airList.add(flight);
				count++;
			}
			if(count>0)
				return airList;
			else
				return null;
		
	}
		catch(SQLException se)
		{
	throw new AirlineException("Database Connection closing Problem.");
}
		
}

	@Override
	public void updatePassword(String email,String password) throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int count=0;
		try{
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.UPDATEPASSWORD);
			pst.setString(1,password);
			pst.setString(2,email);
			pst.executeUpdate();
		}
		catch(SQLException se)
		{
			throw new AirlineException();
		}
	}

	@Override
	public int bookTickets(BookingInformation bookInfo) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet rs = null;
		String bookingId;
		try{
			conn=DBConnection.getInstance().getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.GENERATESEQ);
			ResultSet result=preparedStatement.executeQuery();
			result.next();
			bookingId=result.getString(1);
			preparedStatement=conn.prepareStatement(IQueryMapper.BOOKTICKETS);
			preparedStatement.setString(1,bookingId);
			preparedStatement.setString(2,bookInfo.getCustEmail());
			preparedStatement.setInt(3,bookInfo.getNoOfPassengers());
			preparedStatement.setString(4,bookInfo.getClassType());
			preparedStatement.setDouble(5,bookInfo.getTotalFare());
			preparedStatement.setString(6,bookInfo.getSeatNumbers());
			preparedStatement.setString(7,bookInfo.getCreditCardInfo());
			preparedStatement.setString(8,bookInfo.getDepCity());
			preparedStatement.setString(9,bookInfo.getArrCity());
			preparedStatement.setString(10,bookInfo.getFlightNo());
			preparedStatement.executeUpdate();
			updateFlightInfo(bookInfo.getNoOfPassengers(),bookInfo.getClassType(),bookInfo.getFlightNo());
	}
		catch(SQLException e)
		{
			throw new AirlineException();
		}
		return Integer.parseInt(bookingId);
}

	private void updateFlightInfo(int noOfPassengers, String classType,String flightNo) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet rs = null;
		int count=0;
		try{
			conn=DBConnection.getInstance().getConnection();
			if(classType.equals("Bussiness"))
			{
		
				preparedStatement=conn.prepareStatement(IQueryMapper.UPDATEFLIGHTINFOBUS);
				preparedStatement.setInt(1,noOfPassengers);
				preparedStatement.setString(2,flightNo); 
				preparedStatement.executeUpdate();
			}
			else
			{
				preparedStatement=conn.prepareStatement(IQueryMapper.UPDATEFLIGHTINFOFIRST);
				preparedStatement.setInt(1,noOfPassengers);
				preparedStatement.setString(2,flightNo); 
				preparedStatement.executeUpdate();
			}
			}
			catch(SQLException e)
		{
				
		}
	}

	@Override
	public BookingInformation viewFlightDetails(String bookingId) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet rs = null;
		BookingInformation bookInfo=null;
		{
			System.out.println(bookingId);
			conn=DBConnection.getInstance().getConnection();
			try {
				preparedStatement=conn.prepareStatement(IQueryMapper.VIEWBOOKINGDETAILS);
				preparedStatement.setString(1,bookingId);
				System.out.println(bookingId);
				ResultSet result=preparedStatement.executeQuery();
				while(result.next())
				{
					bookInfo=new BookingInformation();
					bookInfo.setBookingId(result.getString(1));
					bookInfo.setCustEmail(result.getString(2));
					bookInfo.setNoOfPassengers(result.getInt(3));
					bookInfo.setClassType(result.getString(4));
					bookInfo.setCreditCardInfo(result.getString(7));
					bookInfo.setArrCity(result.getString(9));
					bookInfo.setDepCity(result.getString(8));
					bookInfo.setTotalFare(result.getDouble(5));
					bookInfo.setSeatNumbers(result.getString(6));
					bookInfo.setFlightNo(result.getString(10));
				}
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return bookInfo;
	}

	@Override
	public int cancelBooking(String bookingId) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		int count=0;
		{
			conn=DBConnection.getInstance().getConnection();
			try {
				preparedStatement=conn.prepareStatement(IQueryMapper.CANCELBOOKING);
				preparedStatement.setString(1,bookingId);
				count=preparedStatement.executeUpdate();
	}
			catch(SQLException e)
			{
				
			}
			return count;
	
}
	}
	
	@Override
	public List<FlightInformation> getFlightInfoDay(FlightInformation flight) throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int count=0;
		try{
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.GETFLIGHTINFODAY);
			
			pst.setString(1,flight.getArrCity());
			pst.setString(2,flight.getDepTime());
			rs=pst.executeQuery();
			List<FlightInformation> airList=new ArrayList();
			while(rs.next())
			{
				flight.setFlightNo(rs.getString(1));
				flight.setAirline(rs.getString(2));
				flight.setDepDate(rs.getDate(3));
				flight.setArrDate(rs.getDate(4));
				flight.setDepTime(rs.getString(5));
		
				flight.setArrTime(rs.getString(6));
				flight.setFirstSeats(rs.getInt(7));
				flight.setFirstSeatFare(rs.getDouble(8));
				flight.setBussSeats(rs.getInt(9));
				flight.setBussSeatsFare(rs.getDouble(10));
				airList.add(flight);
				count++;
			}
			if(count>0)
				return airList;
			else
				return null;
		
	}
		catch(SQLException se)
		{
	throw new AirlineException("Database Connection closing Problem.");
}
		
}

	@Override
	public void addFlight(FlightInformation flight) throws AirlineException{
		
		
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet rs = null;
		int count=0;
		try
		{
			conn=DBConnection.getInstance().getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.INSERT);	
			
			//System.out.println("hii");
			preparedStatement.setString(1,flight.getFlightNo());
			preparedStatement.setString(2,flight.getAirline());
			preparedStatement.setString(3,flight.getDepCity());
			preparedStatement.setString(4,flight.getArrCity());
			preparedStatement.setDate(5,flight.getDepDate());
			preparedStatement.setDate(6,flight.getArrDate());
			preparedStatement.setString(7,flight.getDepTime());
			preparedStatement.setString(8,flight.getArrTime());
			preparedStatement.setInt(9,flight.getFirstSeats());
			preparedStatement.setDouble(10,flight.getFirstSeatFare());
			preparedStatement.setInt(11,flight.getBussSeats());
			preparedStatement.setDouble(12,flight.getBussSeatsFare());
			preparedStatement.setInt(13,flight.getFirstSeats());
			preparedStatement.setInt(14,flight.getBussSeats());
			
			//System.out.println("hgi");
			count=preparedStatement.executeUpdate();
			//System.out.println(count);
	        }
		catch(SQLException e)
		{
			throw new AirlineException();
		}
		
		
		
		
		
		
	}

	@Override
	public int deleteFlight(FlightInformation flight) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet rs = null;
		int count=0;
		try
		{   
			
			conn=DBConnection.getInstance().getConnection();
		
			preparedStatement=conn.prepareStatement(IQueryMapper.DELETEFLIGHT);
			
			preparedStatement.setString(1, flight.getFlightNo());
			
			
		    preparedStatement.executeUpdate();
		    
		 
	        }
		catch(SQLException e)
		{
			throw new AirlineException();
		}
		
	return count;	
	}

	@Override
	public  int isValidFlightNum(String fnum) throws AirlineException {              // boolean is changed to int
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet rs = null;
		int count=0;
		try
		{
			conn=DBConnection.getInstance().getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.CHECKFLIGHT);
			preparedStatement.setString(1,fnum);
		    count=preparedStatement.executeUpdate();  
			
		
	     }
		catch(SQLException e)
		{
			throw new AirlineException();
		}
	return count;
	}
	@Override
	public List<Integer> viewFlightOcuupancy(FlightInformation f) throws AirlineException {

		//StringBuilder s= new StringBuilder("");
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int firstSeats=0,bussSeats=0,avlbleFrstSeats=0,avlbleBussSeats=0;
		int AvlFreeSeats=0;
		int totalSeats=0;
		int TotalfreeSeats=0;
		List<Integer> viewOccupancy=new ArrayList<Integer>();
		try{
			System.out.println("flghtno"+f.getFlightNo());
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.ViewFlightOccupancy);
			System.out.println("success");
			pst.setString(1,f.getFlightNo());
			rs = pst.executeQuery();
			if(rs.next())
			{
				firstSeats =rs.getInt(1);
				avlbleFrstSeats=rs.getInt(2);
				bussSeats =rs.getInt(3);
				avlbleBussSeats = rs.getInt(4);
				AvlFreeSeats =rs.getInt(2) + rs.getInt(4);
				
				
				totalSeats = rs.getInt(1) + rs.getInt(3);
				TotalfreeSeats= totalSeats-AvlFreeSeats;
				
				System.out.println("updated");
			}
			viewOccupancy.add(firstSeats);
			viewOccupancy.add(avlbleFrstSeats);
			viewOccupancy.add(bussSeats);
			viewOccupancy.add(avlbleBussSeats);
			viewOccupancy.add(totalSeats);
			viewOccupancy.add(TotalfreeSeats);
			
			
	
			
	}
		catch(SQLException e)
		{
			throw new AirlineException();
		}
		
return viewOccupancy;
}
	
}