package com.ars.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.ars.bean.Airport;
import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.exception.AirlineException;
import com.ars.service.AirlineServiceImpl;
import com.ars.service.IAirlineService;

/**
 * Servlet implementation class AirlineController
 */
@WebServlet("/AirlineController")
public class AirlineController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
       private static int bcou=0;
       private static int fcou=0;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AirlineController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String option=request.getParameter("action");
		String userName,password,flightNo ;
		Users user=null;
		FlightInformation flightInfo=null;
		IAirlineService is=null;
		Airport airPort=null;
		BookingInformation bookinfo=null;
		HttpSession session;
		
		switch(option)
		{
		 case "Register":
				userName=request.getParameter("userName");
				password=request.getParameter("password");
				String email=request.getParameter("email");
					user=new Users();
					user.setRole("user");
					user.setuName(userName);
					user.setPassword(password);
					user.setEmail(email);
					is.addUserDetails(user);
					getServletContext().getRequestDispatcher("/RegistrationSuccess.jsp").forward(request,response); 
					break;
		case "login":
			userName=request.getParameter("userName");
			password=request.getParameter("password");
			user=new Users();
			is=new AirlineServiceImpl();
			List depCityList=is.getDepList();
			List arrCityList=is.getArrList();
				if(is.verifyUser(userName,password))
				{
					user.setuName(userName);
					user.setPassword(password);
					if(is.getRole(user).equals("user"))
					{
						session=request.getSession();
						session.setAttribute("user",user);
						session.setAttribute("depCity",depCityList);
						session.setAttribute("arrCity",arrCityList);
						getServletContext().getRequestDispatcher("/userPage.jsp").forward(request, response);
					}
					else if(is.getRole(user).equals("admin"))
					
					{
						session=request.getSession();
						session.setAttribute("user",user);
						session.setAttribute("depCity",depCityList);
						session.setAttribute("arrCity",arrCityList);
						getServletContext().getRequestDispatcher("/AdminPage.jsp").forward(request, response);
					}
					else if(is.getRole(user).equals("executive"))
						
					{
						session=request.getSession();
						session.setAttribute("user",user);
						session.setAttribute("depCity",depCityList);
						session.setAttribute("arrCity",arrCityList);
						getServletContext().getRequestDispatcher("/ExecutivePage.jsp").forward(request, response);

					}
					
				}
				else
				{
					request.setAttribute("error",new AirlineException("Invalid Login Credentials"));
					getServletContext().getRequestDispatcher("/Login.jsp").forward(request, response);
				}
				break;
		case "FlightInfo":
				List<FlightInformation> flightList;
				String src = request.getParameter("depCity");
				String des = request.getParameter("arrCity");
				flightInfo = new FlightInformation();
				flightInfo.setArrCity(des);
				flightInfo.setDepCity(src);
				is=new AirlineServiceImpl();
			//is.getFlightInfo(flightinfo)
				flightList=is.getFlightInfo(flightInfo);
				request.setAttribute("flightList", flightList);
				getServletContext().getRequestDispatcher("/FlightInfoPage.jsp").forward(request, response);
				break;
		case "submit":
				flightNo= request.getParameter("flight");
				is=new AirlineServiceImpl();
				flightInfo=is.getFlightDetails(flightNo);
				airPort=new Airport();
				List<Airport> depAirportList=is.getAirport(flightInfo.getDepCity());
				List<Airport> arrAirportList=is.getAirport(flightInfo.getArrCity());
				session=request.getSession(false);
				session.setAttribute("depAirports",depAirportList);
				session.setAttribute("arrAirports",arrAirportList);
				session.setAttribute("flightDetails", flightInfo);
				getServletContext().getRequestDispatcher("/BookTickets.jsp").forward(request, response);
				break;
		case "booknow":
			 email=request.getParameter("email");
			String classType=request.getParameter("classType");
			int noofPassengers=Integer.parseInt(request.getParameter("no.ofTickets"));
			String creditCardInfo=request.getParameter("creditcard");
			String arrAirport=request.getParameter("arrAirport");
			String depAirport=request.getParameter("depAirport");
			BookingInformation book=new BookingInformation();
			session=request.getSession(false);
			session.setAttribute("depAirport",depAirport);
			session.setAttribute("arrAirport",arrAirport);
			FlightInformation flight=(FlightInformation) session.getAttribute("flightDetails");
			book.setFlightNo(flight.getFlightNo());
			book.setDepCity(flight.getDepCity());
			book.setArrCity(flight.getArrCity());
			book.setCustEmail(email);
			book.setCreditCardInfo(creditCardInfo);
			book.setNoOfPassengers(noofPassengers);
			if(classType.equals("bussinessclass"))
			{
				book.setClassType("Bussiness");
				if(noofPassengers<=flight.getBussAvail())
				{
					book.setTotalFare(noofPassengers*flight.getBussSeatsFare());
				/*System.out.println(book.getTotalFare()+"seatFare");*/
					StringBuffer seatNum=new StringBuffer();
					for(int i=0;i<noofPassengers;i++)
					{
						seatNum.append("BT");
						seatNum.append(++bcou);
						int j=i;
						if(++j<noofPassengers)
							seatNum.append(",");
					}
					book.setSeatNumbers(seatNum.toString());
				}
				else
				{
					throw new AirlineException("No More Seats available to book");
				}
			}
			else
			{
				book.setClassType("First");
				/*book.setClassType("Bussiness");*/
				if(noofPassengers<=flight.getFirstAvail())
				{
				book.setTotalFare(noofPassengers*flight.getFirstSeatFare());
				/*System.out.println(book.getTotalFare()+"seatFare"+flightinfo.getFirstSeatFare());*/
				StringBuffer seatNum=new StringBuffer();
				for(int i=0;i<noofPassengers;i++)
				{
					seatNum.append("FT");
					seatNum.append(++fcou);
					int j=i;
					if(++j<noofPassengers)
					seatNum.append(",");
				}
				book.setSeatNumbers(seatNum.toString());
				}
				else
				{
					throw new AirlineException("No More Seats available to book");
				}
			}
			book.setNoOfPassengers(noofPassengers);
			is=new AirlineServiceImpl();
			String booking = is.bookTicket(book);
				session.setAttribute("bookingId",booking);
				getServletContext().getRequestDispatcher("/booking.jsp").forward(request,response);
				break;
		case "viewDetail":
			getServletContext().getRequestDispatcher("/viewDetail.jsp").forward(request,response);
			break;
		case "viewDetails":
				session=request.getSession(false);
				String bookingId=request.getParameter("bookingId");
				/*String bookingId=(String) session.getAttribute("bookingId");*/
			is=new AirlineServiceImpl();
				book=is.viewFlightDetails(bookingId);
			if(book!=null)
			{
				flightInfo=is.getFlightDetails(book.getFlightNo());
	        session.setAttribute("book",book);
	        session.setAttribute("flightDetails",flightInfo);
	      /*  System.out.println(flightInfo.getArrTime());*/
			/*System.out.println("BookingId:"+bookInfo.getBookingId()+"\nCustomer Email:"+bookInfo.getCustEmail()+"\nno of passengers:"+bookInfo.getNoOfPassengers()+"\nClass Type:"+bookInfo.getClassType()+"\nTotal Fare:"+bookInfo.getTotalFare()+"\nSeat Numbers:"+bookInfo.getSeatNumbers()+"\nCredit Card info"+bookInfo.getCreditCardInfo()+"\nDeparture City:"+bookInfo.getDepCity()+"\nArrival City"+bookInfo.getArrCity());*/
	        getServletContext().getRequestDispatcher("/viewDetails.jsp").forward(request,response);
			}
			else
			{
				throw new AirlineException("Invalid Flight Number");
			}
			break;
		case "cancelTicket":
			getServletContext().getRequestDispatcher("/cancelTicket.jsp").forward(request,response);
			break;
		case "cancelTickets":
			bookingId=request.getParameter("bookingId");
			session=request.getSession(false);
			is=new AirlineServiceImpl();
			int count=is.cancelBooking(bookingId);
			if(count==1)
			{
				
				session.setAttribute("bookingId",bookingId);
				getServletContext().getRequestDispatcher("/cancelBooking.jsp").forward(request,response);
			}
			else
			{
				request.setAttribute("error",new AirlineException("Invalid Flight Number"));
				getServletContext().getRequestDispatcher("/error.jsp").forward(request,response);
			}
			break;
		case "addFlight":
			getServletContext().getRequestDispatcher("/addFlight.jsp").forward(request,response);
			break;
		case "addFlightDetails":
			flightInfo=new FlightInformation();
			flightInfo.setFlightNo(request.getParameter("flightNum"));
			flightInfo.setAirline(request.getParameter("airlineName"));
			flightInfo.setDepCity(request.getParameter("depCity"));
			flightInfo.setArrCity(request.getParameter("arrCity"));
			String da=request.getParameter("depDate");
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date dateut = sdf1.parse(da);
			java.sql.Date date1 = new java.sql.Date(dateut.getTime()); 
			flightInfo.setDepDate(date1);
			String dat=request.getParameter("arrDate");
			sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			dateut = sdf1.parse(dat);
			date1 = new java.sql.Date(dateut.getTime()); 
			flightInfo.setArrDate(date1);
			flightInfo.setDepTime(request.getParameter("depTime"));
			flightInfo.setArrTime(request.getParameter("arrTime"));
			flightInfo.setBussSeats(Integer.parseInt(request.getParameter("bussSeats")));
			flightInfo.setFirstSeats(Integer.parseInt(request.getParameter("firstSeats")));
			flightInfo.setBussSeatsFare(Double.parseDouble(request.getParameter("bussSeatsFare")));
			flightInfo.setFirstSeatFare(Double.parseDouble(request.getParameter("firstSeatsFare")));
			is=new AirlineServiceImpl();
			is.addFlight(flightInfo);
			session=request.getSession(false);
			session.setAttribute("flightNum",flightInfo.getFlightNo());
			getServletContext().getRequestDispatcher("/addSuccessfully.jsp").forward(request,response);
			break;
		case "deleteFlight":
			getServletContext().getRequestDispatcher("/deleteflight.jsp").forward(request,response);
			break;
		case "cancelFlight":
			String flightNum=request.getParameter("flightNum");
			is=new AirlineServiceImpl();
			flightInfo=new FlightInformation();
			if(is.isValidFlightNum(flightNum)==1)
			{
				flightInfo.setFlightNo(flightNum);
				if(is.deleteFlight(flightInfo)==1)
				{	request.setAttribute("flightNum",flightNum);
					getServletContext().getRequestDispatcher("/deleteSuccess.jsp").forward(request,response);
				}
				else
				{ 
					request.setAttribute("error",new AirlineException("Invalid Flight Number"));
					getServletContext().getRequestDispatcher("/error.jsp").forward(request,response);
					
				}	
			}
			break;
		case "manageFlight":
			getServletContext().getRequestDispatcher("/manageflight.jsp").forward(request,response);
			break;
		case "modify":
			String choice=request.getParameter("modify");
			String val=request.getParameter("change");
			flightNum=request.getParameter("flightnum");
			is=new AirlineServiceImpl();
			String c,msg=null;
			if(choice.equals("change source"))
			{
				c="dep_city";
			is.adminModify(c,val,flightNum);
			msg="Departure City changed Successfully";
			}
			else if(choice.equals("change destination"))
			{
				c="arr_city";
				is.adminModify(c,val,flightNum);
				msg="Arrival City changed Successfully";
			}
			else if(choice.equals("change airlines name"))
			{
				c="airline";
				is.adminModify(c,val,flightNum);
				msg="Airlines changed Successfully";
			}

			else if(choice.equals("change firstseatsfare"))
			{
				c="firstseatfare";
				is.adminModify(c,val,flightNum);
				msg="First Seats Fare Changed Successfully";
			}
			else if(choice.equals("change bussseatsfare"))
			{
				c="bussseatsfare";
				is.adminModify(c,val,flightNum);
				msg="Bussiness Seats Fare Changed Successfully";
			}
			else if(choice.equals("change dep date"))
			{
				c="dep_date";
				is.adminModify(c,val,flightNum);
				msg="Departure Date Changed Successfully";
			}
			else if(choice.equals("change dep time"))
			{
				c="dep_time";
				is.adminModify(c,val,flightNum);
				msg="Departure Time Changed Successfully";
			}	
			session=request.getSession(false);
			session.setAttribute("message",msg+" to "+val+" for flight Number:"+flightNum);
			getServletContext().getRequestDispatcher("/modifiedSuccess.jsp").forward(request,response);
			break;
		case "generateReports":
			getServletContext().getRequestDispatcher("/generatereport.jsp").forward(request,response);
			break;
		case "generateReport":
			choice=request.getParameter("report");
			System.out.println(choice);
			if(choice.equals("destination"))
			{
				val=request.getParameter("val");
				dat=request.getParameter("depDate");
				System.out.println(dat);
				sdf1 = new SimpleDateFormat("yyyy-MM-dd");
				dateut = sdf1.parse(dat);
				date1 = new java.sql.Date(dateut.getTime()); 
				is=new AirlineServiceImpl();
				flightInfo=new FlightInformation();
				flightInfo.setDepDate(date1);
				flightInfo.setArrCity(val);
				flightList=is.getFlightInfoDay(flightInfo);
				session=request.getSession(false);
				session.setAttribute("flightList",flightList);
				getServletContext().getRequestDispatcher("/generateforDate.jsp").forward(request,response);
			}
			else if(choice.equals("specificFlight"))
			{
				val=request.getParameter("val");
				List<BookingInformation> bookList;
				IAirlineService bd=new AirlineServiceImpl();
				bookinfo= new BookingInformation();
				bookinfo.setFlightNo(val);
				bookList=bd.getFlightBook(bookinfo);
				session=request.getSession(false);
				session.setAttribute("bookList",bookList);
				getServletContext().getRequestDispatcher("/separatePage.jsp").forward(request,response);
			}
			else
			{
				flightNum=request.getParameter("val");
				bookinfo=new BookingInformation();
				bookinfo.setFlightNo(flightNum);
				is=new AirlineServiceImpl();
				List<BookingInformation> bookList;
				bookList=is.getPassengerList(bookinfo);
				session=request.getSession(false);
				session.setAttribute("flightNum",flightNum);
				session.setAttribute("passengers",bookList);
				getServletContext().getRequestDispatcher("/passengerList.jsp").forward(request,response);
			}
		case "viewbyflightnum":
			getServletContext().getRequestDispatcher("/viewByFlightNum.jsp").forward(request,response);
		case "viewByFlightNumber":
			flightNum=request.getParameter("flightNum");
			flightInfo=new FlightInformation();
			flightInfo.setFlightNo(flightNum);
			is=new AirlineServiceImpl();
			List<FlightInformation> flightOccupancy= is.viewFlightOcuupancy(flightInfo);
			session=request.getSession(false);
			session.setAttribute("flightSeats",flightOccupancy);
			session.setAttribute("flightNum",flightNum);
			getServletContext().getRequestDispatcher("/occupancy.jsp").forward(request,response);
			break;
		case "viewbycity":
			getServletContext().getRequestDispatcher("/viewByCity.jsp").forward(request,response);
			break;
		case "viewByCity":
			String depCity=request.getParameter("depCity");
			String arrCity=request.getParameter("arrCity");
			is=new AirlineServiceImpl();
			flightList=is.viewByCity(depCity,arrCity);
			session=request.getSession(false);
			session.setAttribute("flightList",flightList);
			getServletContext().getRequestDispatcher("/occupancyList.jsp").forward(request,response);
			break;
		case "ReservationForm":
			getServletContext().getRequestDispatcher("/ReservationForm.jsp").forward(request,response);
			break;
		}
		}
		
		catch (Exception e) {
					} 
	}
	}