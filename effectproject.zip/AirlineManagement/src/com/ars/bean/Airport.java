package com.ars.bean;

public class Airport {
private String airportName;
private String abbreviation;
private String  city;
public String getAirportName() {
	return airportName;
}
public void setAirportName(String airportName) {
	this.airportName = airportName;
}
public String getAbbreviation() {
	return abbreviation;
}
public void setAbbreviation(String abbreviation) {
	this.abbreviation = abbreviation;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}

}
