package com.ars.pi;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.dao.AirlineDaoImpl;
import com.ars.dao.IAirlineDao;
import com.ars.exception.AirlineException;
import com.ars.service.AirlineServiceImpl;
import com.ars.service.IAirlineService;

public class AirlineMain {
	static int bcou=0;
	static int fcou=0;
	private static IAirlineService is;
	public static void main(String[] args) {
			int choice,coun=0;
			String uName,password,email,pass;
			IAirlineService is=new AirlineServiceImpl();
			Users user=null;
			try{
			Scanner scan=new Scanner(System.in);
			while(true)
			{
			System.out.println("Choose from below options:");
			System.out.println("1.Register\n2.Login\n3.Exit");
			choice=scan.nextInt();
			while(true){
				switch(choice)
				{
				case 1:
					System.out.println("Please enter the details to complete registration:");
					do{
					System.out.println("UserName:");
					 uName=scan.next();
					}
					while(is.isValidName(uName));
					do{
					System.out.println("Password:");
					password=scan.next();
					}while(is.isValidPassword(password));
					do{
					System.out.println("E-mail:");
					email=scan.next();
					}while(is.isValidEmail(email));
					user=new Users();
					user.setRole("user");
					user.setuName(uName);
					user.setPassword(password);
					user.setEmail(email);
					is.addUserDetails(user);
				case 2:
					System.out.println("Please enter your login credentials:");
					do{
						user=new Users();
						System.out.println("UserName:");
						uName=scan.next();
						System.out.println("Password:");
						password=scan.next();
						coun++;
						if(coun==3)
						{
							System.out.println("You Need to Reset your password.");
							System.out.println("Enter your email ID");
							email=scan.next();
							System.out.println("Enter new password to login");
							pass=scan.next();
							is.isValidPassword(pass);
							is.updatePassword(email,pass);
							coun=0;
						}	
					}while(is.verifyUser(uName,password));
					user.setuName(uName);
					user.setPassword(password);
					if(is.getRole(user).equals("user"))
						while(true)
						{
						getAirlines(user);
						}
					else if(is.getRole(user).equals("admin"))
						getAdminFunc(user);
					else if(is.getRole(user).equals("executive"))
						getExecutiveRole(user);
				case 3:
					System.exit(0);
				}
			}
		}
	}
			catch(AirlineException|ParseException ae)
			{
				System.out.println("hello");
				System.err.println("Error Occured"+ae.getMessage());
				main(args);
			}
			
	}

	private static void getExecutiveRole(Users user) throws AirlineException {
		FlightInformation f = null;
		int count=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter flight number");
		String flightNum=scan.next();
		f=new FlightInformation();
		f.setFlightNo(flightNum);
		IAirlineService is=new AirlineServiceImpl();
		List<Integer> freeseats= is.viewFlightOcuupancy(f);
		for(Integer i:freeseats)
		{
			if(count==0)
			{
				System.out.println("first class Seats:");
			}
			else if(count==1)
			{
				System.out.println("available first clas seats:");
			}
			else if(count==2)
			{
				System.out.println("bussiness class seats:");
			}
			else if(count==3)
			{
				System.out.println("available bussiness class seats:");
			}
			else if(count==4)
			{
				System.out.println("total seats:");
			}
			else if(count==5)
			{
				System.out.println("available free seats:");
			}
			System.out.println(i);
			count++;
		}
		
	}

	private static void getAdminFunc(Users user) throws ParseException, AirlineException {
		System.out.println("Dear admin, these are the actions you can perform");
		System.out.println("1 Add Flights\n");
		System.out.println("2 Delete Flights\n");
		System.out.println("3 Update Flight schedules\n");
		System.out.println("4 Generating  ");
		int ch;
		FlightInformation flight=null;
		Scanner scan=new Scanner(System.in);
		ch=scan.nextInt();
		if(ch==1)
		{
			System.out.println("Here we go to add a flight's details...");
			System.out.println("Enter flight number to be added into flight list: ");
			String fnum;
			fnum=scan.next();
			//System.out.println(fnum);
			System.out.println("Enter the airlines to which the flight belongs to");
			String fairline;
			fairline=scan.next();
			System.out.println("Enter the departure city");
			String fdeptcity;
			fdeptcity=scan.next();
			System.out.println("Enter the arrival city");
			String farrivalcity;
			farrivalcity=scan.next();
			System.out.println("Enter the departure date(dd/mm/yyyy)");
			String fdepdate;
			fdepdate=scan.next();
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date dateut = sdf1.parse(fdepdate);
			java.sql.Date date1 = new java.sql.Date(dateut.getTime()); 
			System.out.println(date1);
			System.out.println("Enter the arrival date(dd/mm/yyyy)");
			String farrdate;	
			farrdate=scan.next();
			SimpleDateFormat sdf2 = new SimpleDateFormat("dd-MM-yyyy");
			java.util.Date dateut1 = sdf2.parse(fdepdate);
			java.sql.Date date2 = new java.sql.Date(dateut1.getTime()); 
			System.out.println("Enter the departure time");
			String fdeptime;
			fdeptime=scan.next();
			System.out.println("Enter the arrival time");
			String farrtime;
			farrtime=scan.next();
			System.out.println("Enter the no of first class seats in the flight");
			int ffirst;
			ffirst=scan.nextInt();
			System.out.println("Enter the first class seats fare");
			int ffirstfare;
			ffirstfare=scan.nextInt();
			System.out.println("Enter the business class seats in the flight");
			int fbuss;
			fbuss=scan.nextInt();
			System.out.println("Enter the bussiness class seats fare");
			int fbussfare;
			fbussfare=scan.nextInt();
			System.out.println("Your insertion of flight is successful");
			
			
			flight=new FlightInformation();
			flight.setFlightNo(fnum);
			System.out.println(flight.getFlightNo());
			flight.setAirline(fairline);
		    flight.setDepCity(fdeptcity);
			flight.setArrCity(farrivalcity);
			flight.setDepDate(date1);
			flight.setArrDate(date2);
			flight.setArrTime(farrtime);
			flight.setDepTime(fdeptime);
			flight.setFirstSeats(ffirst);
			flight.setFirstSeatFare(ffirstfare);
			flight.setBussSeats(fbuss);
			flight.setBussSeatsFare(fbussfare);
			
			IAirlineService add=new AirlineServiceImpl();
			add.addFlight(flight);
			
		    
			
		}
		else if(ch==2)
		{
			System.out.println("Here we go to delete a flight's details");
			System.out.println("Enter the flight number to get deleted from the flight list");
			String fnum;
			fnum=scan.next();
			flight=new FlightInformation();
			flight.setFlightNo(fnum);
			
			IAirlineService del=new AirlineServiceImpl();
			
			if(del.isValidFlightNum(fnum)==1)
			{
				
				if(del.deleteFlight(flight)==1)
				{
					
					System.out.println("Your deletion was successful");	
				}
				else
				{ 
					
					System.out.println("Here we go to update a flight's schedules");
				}
				
				
				
			}
			
				
			}
		else if(ch==3)
		{
			
		}
		else if(ch==4)
		{
			System.out.println("Here we go to get the details of the flight");
			System.out.println("Dear admin, these are the reports you can generate");
			System.out.println("1 view list of flights on a particular day to a particular destination\n");
			System.out.println("2 view bookings of a specific flight\n");
			System.out.println("3 view passenger list of specific flight");
			int cho;
			cho=scan.nextInt();
			if(cho==1)
			{
				System.out.println("Here we are about to know the details of the flights on a particular day to a particular destination");
				
				System.out.println("Enter the arrival city where you want to go");
				String farr;
				farr=scan.next();
				
				
				System.out.println("enter the departure date in dd/mm/yyyy format");
				String fdepdate;
				fdepdate=scan.next();
				
				
				
				SimpleDateFormat sdf2 = new SimpleDateFormat("dd/MM/yyyy");
				java.util.Date dateut1 = sdf2.parse(fdepdate);
				java.sql.Date date2 = new java.sql.Date(dateut1.getTime());
				
				
				
				
				List<FlightInformation> flightList;
				IAirlineService viewfdate=new AirlineServiceImpl();
				FlightInformation finfo=new FlightInformation();
				
				finfo.setDepDate(date2);
				finfo.setArrCity(farr);
				flightList=viewfdate.getFlightInfoDay(finfo);
			    if(flightList!= null)
			    {
			    	Iterator<FlightInformation> ie= flightList.iterator();
			    	while(ie.hasNext())
			    	{
			    		FlightInformation fi=ie.next();
			    		System.out.println("Flight number is :"+fi.getFlightNo());
			    		System.out.println("Flight airline is :"+fi.getAirline());
			    		System.out.println("Flight departure city :"+fi.getDepCity());
			    		System.out.println("Flight arrival city is :"+fi.getArrCity());
			    		System.out.println("Flight departure date is  :"+fi.getDepDate());
			    		System.out.println("Flight arrival date is :"+fi.getArrDate());
			    		System.out.println("Flight dearture time is :"+fi.getDepTime());
			    		System.out.println("flight arrival time is :"+fi.getArrTime());
			    		System.out.println("Flight First class seats is :"+fi.getFirstSeats());
			    		System.out.println("Flight first class seats fare is :"+fi.getFirstSeatFare());
			    		System.out.println("Flight business class seats is :"+fi.getBussSeats());
			    		System.out.println("Flight business class seats fare is :"+fi.getBussSeatsFare());
			    		System.out.println("Flight's available for first class seats is :"+fi.getFirstAvail());
			    		System.out.println("Flight's available for business class seats is :"+fi.getBussAvail());
			    	}
			    	
			    }
				
				
				
				
				
		    }
			else if(cho==2)
			{
				System.out.println("Here we are about to know the booking details of the specific flight");
				String fnum;
				fnum=scan.next();
				List<BookingInformation> bookList;
				IAirlineService bd=new AirlineServiceImpl();
				BookingInformation bookinfo= new BookingInformation();
				bookinfo.setFlightNo(fnum);
				bookList=bd.getFlightBook(bookinfo);
				if (bookList != null) {
					Iterator<BookingInformation> i = bookList.iterator();
					while (i.hasNext()) {
						BookingInformation bi=i.next();
						System.out.println("booking id No:"+bi.getBookingId());
						System.out.println("email:"+bi.getCustEmail());
						System.out.println("passenger count:"+bi.getNoOfPassengers());
						System.out.println("class type:"+bi.getClassType());
						System.out.println("total fare:"+bi.getTotalFare());
						System.out.println("seat numbers:"+bi.getSeatNumbers());
						System.out.println("credit card info:"+bi.getCreditCardInfo());
						System.out.println("departure city:"+bi.getDepCity());
						System.out.println("arrival city:"+bi.getArrCity());
						System.out.println("flight no:"+bi.getFlightNo());
						System.out.println("--------------------------");
					}
				}
				
				
			}
		}
		
	}

	private static void getAirlines(Users user) throws AirlineException {
		Scanner scan=new Scanner(System.in);
		int choice;
		String flightNum;
		
		List<FlightInformation> airList;
		IAirlineService is = null;
		BookingInformation bookInfo=null;
		System.out.println("Welcome to Capgemini Airlines.");
		System.out.println("Please choose from below options:");
		System.out.println("1)Book Ticket\n2)View Ticket Info\n3)Cancel Booking\n4)Exit");
		choice=scan.nextInt();
			switch(choice)
			{
			case 1:
			System.out.println("Please Enter your Source city:");
			String depCity=scan.next();
			System.out.println("Please Enter your destination city:");
			String arrCity=scan.next();
			is=new AirlineServiceImpl();
			FlightInformation flightinfo= new FlightInformation();
			flightinfo.setDepCity(depCity);
			flightinfo.setArrCity(arrCity);
			airList=is.getFlightInfo(flightinfo);
			if (airList != null) {
				Iterator<FlightInformation> i = airList.iterator();
				while (i.hasNext()) {
					flightinfo=i.next();
					System.out.println("FlightNumber:"+flightinfo.getFlightNo()+"\nairline name:"+flightinfo.getAirline()+"\ndeparture city:"+flightinfo.getDepCity()+"\nArrival City:"+flightinfo.getArrCity()+"\nDeparture Date:"+flightinfo.getDepDate()+"\nArrival Date:"+flightinfo.getArrDate()+"\nDeparture Time:"+flightinfo.getDepTime()+"\nArrival Time:"+flightinfo.getArrTime()+"\nFirst Seats Available:"+flightinfo.getFirstAvail()+"\nBussiness Seats available:"+flightinfo.getBussAvail()+"\nFirst Seats Fare"+flightinfo.getFirstSeatFare()+"\nBussiness Seats Fare:"+flightinfo.getBussSeatsFare());
				}
			}
		/*	bookTickets(is);*/
			/*Scanner scan=new Scanner(System.in);*/
			do{
			System.out.println("Enter flightno to book ticket");
			flightNum=scan.next();
			}while(is.isValidFlightNum(flightNum)!=1);
			System.out.println("Choose the class type from the following:");
			System.out.println("1)Bussiness Class 2)First Class");
			int type=scan.nextInt();
			System.out.println("Enter no of tickets:");
			int noofTickets=scan.nextInt();
			System.out.println("Enter your email id:");
			String email=scan.next();
			System.out.println("Enter your creditCard info");
			String card=scan.next();
		    bookInfo=new BookingInformation();
			bookInfo.setFlightNo(flightNum);
			if(type==1)
			{
				bookInfo.setClassType("Bussiness");
				if(noofTickets<=flightinfo.getBussAvail())
				{
					bookInfo.setTotalFare(noofTickets*flightinfo.getBussSeatsFare());
				/*System.out.println(bookInfo.getTotalFare()+"seatFare");*/
					StringBuffer seatNum=new StringBuffer();
					for(int i=0;i<noofTickets;i++)
					{
						seatNum.append("BT");
						seatNum.append(++bcou);
						int j=i;
						if(++j<noofTickets)
							seatNum.append(",");
					}
					bookInfo.setSeatNumbers(seatNum);
				}
				else
				{
					throw new AirlineException("No Seats available to book tickets");
				}
			}
			else
			{
				bookInfo.setClassType("First");
				/*bookInfo.setClassType("Bussiness");*/
				if(noofTickets<=flightinfo.getBussAvail())
				{
				bookInfo.setTotalFare(noofTickets*flightinfo.getFirstSeatFare());
				/*System.out.println(bookInfo.getTotalFare()+"seatFare"+flightinfo.getFirstSeatFare());*/
				StringBuffer seatNum=new StringBuffer();
				for(int i=0;i<noofTickets;i++)
				{
					seatNum.append("FT");
					seatNum.append(++fcou);
					int j=i;
					if(++j<noofTickets)
					seatNum.append(",");
				}
				bookInfo.setSeatNumbers(seatNum);
				}
				else
				{
					throw new AirlineException("No Seats available to book tickets");
				}
			}
			bookInfo.setNoOfPassengers(noofTickets);
			bookInfo.setArrCity(arrCity);
			bookInfo.setDepCity(depCity);
			bookInfo.setCreditCardInfo(card);
			bookInfo.setCustEmail(email);
			
			int booking=is.bookTicket(bookInfo);
			System.out.println("Your booking id:"+booking);
			break;
			case 2:
				System.out.println("Enter booking Id to view details:");
				String bookingId=scan.next();
				is=new AirlineServiceImpl();
				bookInfo=is.viewFlightDetails(bookingId);
				if(bookInfo!=null)
				{
				bookInfo.setBookingId(bookingId);
				System.out.println("Your booking details are:");
				System.out.println("BookingId:"+bookInfo.getBookingId()+"\nCustomer Email:"+bookInfo.getCustEmail()+"\nno of passengers:"+bookInfo.getNoOfPassengers()+"\nClass Type:"+bookInfo.getClassType()+"\nTotal Fare:"+bookInfo.getTotalFare()+"\nSeat Numbers:"+bookInfo.getSeatNumbers()+"\nCredit Card info"+bookInfo.getCreditCardInfo()+"\nDeparture City:"+bookInfo.getDepCity()+"\nArrival City"+bookInfo.getArrCity());
				}
				break;
			case 3:
				System.out.println("Enter booking Id for cancelling ticket(s)");
				bookingId=scan.next();
				System.out.println("Are you sure you want to book tickets?");
				System.out.println("Enter 1)to continue 2)exit");
				int ch=scan.nextInt();
				if(ch==1)
				{
					is=new AirlineServiceImpl();
					int count=is.cancelBooking(bookingId);
					if(count==1)
					{
						System.out.println("You have cancelled the flight booking with booking Id:"+bookingId);
					}
					else
					{
						System.out.println("Your Booking doesn't exists");
					}
				}
					else
					{
						System.exit(0);
					}
			break;
			case 4:
				System.exit(0);
		}
		
	}
	public static void bookTickets(IAirlineService is) throws AirlineException
	{
		
	}
}
