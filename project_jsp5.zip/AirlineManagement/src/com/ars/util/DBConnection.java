package com.ars.util;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.activation.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import oracle.jdbc.pool.OracleDataSource;

import com.ars.exception.AirlineException;

public class DBConnection {
	private static Connection con = null;
	private static DBConnection instance = null;
	private static Properties props = null;
	private static OracleDataSource dataSource = null;

	/*****************************************************************
	 *  - Method Name:getConnection() 
	 *  - Input Parameters : 
	 *  - Return Type :DBConnection instance
	 *  - Throws : AirlineException 
	 *  - Author : CAPGEMINI 
	 *  - Creation Date : 18/06/2018
	 *  - Description :  Returns connection object
	 *******************************************************************/
	public static Connection getConnection() throws AirlineException {
		try {

			InitialContext ic=new InitialContext();
			javax.sql.DataSource ds;
				ds = (javax.sql.DataSource) ic.lookup("java:/jdbc/OracleDS");
			con=ds.getConnection();

		} catch (SQLException|NamingException e) {
			throw new AirlineException(" Database connection problem");
		}
		return con;
}

}