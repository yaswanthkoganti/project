package com.airlinereservationsystem.service;

import java.util.List;

import com.airlinereservationsystem.bean.Airport;
import com.airlinereservationsystem.bean.BookingInformation;
import com.airlinereservationsystem.bean.FlightInformation;
import com.airlinereservationsystem.bean.Users;
import com.airlinereservationsystem.exception.AirlineException;

public interface IAirlineService {

	boolean isValidName(String uName) throws AirlineException;

	boolean isValidPassword(String password);

	boolean isValidEmail(String email) throws AirlineException;

	boolean verifyUser(String uName, String password) throws AirlineException;

	void addUserDetails(Users user) throws AirlineException;
	String getRole(Users user) throws AirlineException;

	List<FlightInformation> getFlightInfo(FlightInformation flightinfo) throws AirlineException;

	void updatePassword(String email, String pass) throws AirlineException;

	String bookTicket(BookingInformation bookInfo) throws AirlineException;

	BookingInformation viewFlightDetails(String flightNum) throws AirlineException;

	int cancelBooking(String bookingId) throws AirlineException;

	void addFlight(FlightInformation flight) throws AirlineException;

	int deleteFlight(FlightInformation flight) throws AirlineException;

	int isValidFlightNum(String fnum) throws AirlineException;

	List<FlightInformation> getFlightInfoDay(FlightInformation flightinfo)
			throws AirlineException;

	List<FlightInformation> viewFlightOcuupancy(FlightInformation f)
			throws AirlineException;

	List<BookingInformation> getFlightBook(BookingInformation bookinfo)
			throws AirlineException;
	
	 FlightInformation getFlightDetails(String fNo) throws AirlineException;

	List<Airport> getAirport(String city) throws AirlineException;

	List<BookingInformation> getPassengerList(BookingInformation bookinfo) throws AirlineException;

	void adminModify(String c, String val, String flightNum) throws AirlineException;

	List<FlightInformation> viewByCity(String depCity, String arrCity) throws AirlineException;

	List getDepList() throws AirlineException;

	List getArrList() throws AirlineException;
}
