package com.airlinereservationsystem.exception;

public class AirlineException extends Exception {
private String msg;
	public AirlineException()
	{
		
	}
	public AirlineException(String string) {
	this.msg=string;
	}
public String toString()
{
	return this.msg;
}
}
