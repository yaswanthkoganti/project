package com.ars.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.dao.AirlineDaoImpl;
import com.ars.exception.AirlineException;

class AirlineTest {
	static AirlineDaoImpl air=null;
	static Users user=null;
	static BookingInformation bookInfo=null;
	static FlightInformation flight=null;
	@BeforeClass
	public static void Initialize()
	{
		air=new AirlineDaoImpl();
		user=new Users();
		bookInfo=new BookingInformation();
		flight=new FlightInformation();
		
	}
	@Test (/*expected =AirlineException.class*/)
	void testLogin() {
		try {
			assertSame(true,air.verifyUser("admin","admin"),"welcome");
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test (/*expected =AirlineException.class*/)
	void testLogin1() {
		try {
			user.setuName("Yaswanth");
			user.setPassword("Yash23");
			assertSame(true,air.getRole(user),"welcome");
			
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@Test (/*expected =AirlineException.class*/)
	void testTicketBooking() {
		try {
			bookInfo.setFlightNo("1234");
			bookInfo.setTotalFare(70000);
			bookInfo.setClassType("Bussiness");
			bookInfo.setSeatNumbers(new StringBuffer("BT1,BT2"));
			bookInfo.setNoOfPassengers(2);
			bookInfo.setArrCity("hyd");
			bookInfo.setDepCity("chennai");
			bookInfo.setCreditCardInfo("1234567689");
			bookInfo.setCustEmail("yash@gmail.com");
			assertSame(10060,air.bookTickets(bookInfo));
			
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test (/*expected =AirlineException.class*/)
	void testTicketBooking1() {
		try {
			bookInfo.setFlightNo("1234");
			bookInfo.setTotalFare(70000);
			bookInfo.setClassType("Bussiness");
			bookInfo.setSeatNumbers(new StringBuffer("BT1,BT2"));
			bookInfo.setNoOfPassengers(2);
			bookInfo.setArrCity("hyd");
			bookInfo.setDepCity("chennai");
			bookInfo.setCreditCardInfo("1234567689");
			bookInfo.setCustEmail("yash@gmail.com");
			assertNotSame(100001,air.bookTickets(bookInfo));
			
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test (/*expected =AirlineException.class*/)
	void testViewFlights() {
		try {
			flight.setDepCity("chennai");
			flight.setDepCity("hyd");
			assertNotNull(air.getFlightInfo(flight));
			
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test (/*expected =AirlineException.class*/)
	void testViewFlights2() {
		try {
			flight.setDepCity("chennai");
			flight.setDepCity("chennai");
			assertNull(air.getFlightInfo(flight));
			
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	void testViewFlightDetails() {
		try {
			assertNotNull(air.viewFlightDetails("10030"));
			
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
void testCancelBooking()
{
	try {
		assertSame(1,air.cancelBooking("10030"));
		
	} catch (AirlineException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

	@Test
	void testDeleteFlight()
	{
		try {
			flight.setFlightNo("1234");
			assertSame(1,air.deleteFlight(flight));
			
		} catch (AirlineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
