package com.ars.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.dao.AirlineDaoImpl;
import com.ars.dao.IAirlineDao;
import com.ars.exception.AirlineException;

public class AirlineServiceImpl implements IAirlineService{

	@Override
	public boolean isValidName(String uName) throws AirlineException {
		Pattern p=Pattern.compile("[A-Z][a-z A-Z]{3,}");
		Matcher m=p.matcher(uName);
		if(m.matches())
			return false;
		else
		{
				/*try{*/
				throw new AirlineException("Invalid user name Please retry...");
				//}
				//finally{
				//System.err.println("Invalid");
				//return true;
			}
	}

	@Override
	public boolean isValidPassword(String password) {
		Pattern p=Pattern.compile("[A-Za-z.@!#$%^&]*{4,}");
		Matcher m=p.matcher(password);
		if(m.matches())
			return false;
		else
		{
			try{
			throw new AirlineException("Invalid user name Please retry...");
			}
			finally{
			return true;
			}
		}
	}

	@Override
	public boolean isValidEmail(String email) {
		Pattern p=Pattern.compile(".*@.*");
		Matcher m=p.matcher(email);
		if(m.matches())
			return false;
		else
		{
			/*try{
			//throw new AirlineException("Invalid user name Please retry...");
			}
			finally{*/
			System.err.println("Invalid");
			return true;
		}
	}

	@Override
	public boolean verifyUser(String uName, String password) throws AirlineException {
		IAirlineDao ia=new AirlineDaoImpl();
		return ia.verifyUser(uName,password);

}

	@Override
	public void addUserDetails(Users user) throws AirlineException {
		IAirlineDao ia=new AirlineDaoImpl();
		ia.addUserDetails(user);
	}
	@Override
	public String getRole(Users user) throws AirlineException
	{
		IAirlineDao ia=new AirlineDaoImpl();
		return ia.getRole(user);
	}

	@Override
	public List<FlightInformation> getFlightInfo(FlightInformation flight) throws AirlineException {
		IAirlineDao ia=new AirlineDaoImpl();
		return ia.getFlightInfo(flight);
	}

	@Override
	public void updatePassword(String email,String password) throws AirlineException {
		IAirlineDao ia=new AirlineDaoImpl();
		ia.updatePassword(email,password);
		
	}

	@Override
	public void bookTicket(BookingInformation bookInfo) throws AirlineException {
		IAirlineDao ia=new AirlineDaoImpl();
		ia.bookTickets(bookInfo);
	}

	@Override
	public void addFlight(FlightInformation flight) throws AirlineException  {
		IAirlineDao ia=new AirlineDaoImpl();
		ia.addFlight(flight);
		
	}

	@Override
	public int deleteFlight(FlightInformation flight) throws AirlineException {
		IAirlineDao ia=new AirlineDaoImpl();
		return ia.deleteFlight(flight);
		
	}

	@Override
	public int isValidFlightNum(String fnum) throws AirlineException {
		IAirlineDao ia=new AirlineDaoImpl();
		return ia.isValidFlightNum(fnum);
	}

	@Override
	public List<FlightInformation> getFlightInfoDay(FlightInformation flightinfo) throws AirlineException{
	IAirlineDao ia=new AirlineDaoImpl();
	return ia.getFlightInfo(flightinfo);
	}
}
