package com.ars.bean;

public class BookingInformation {
private String bookingId;
private String custEmail;
private int noOfPassengers;
private String classType;
private double totalFare;
private String seatNumbers;
private String creditCardInfo;
private String arrCity;
private String depCity;
private String flightNo;
public String getFlightNo() {
	return flightNo;
}
public void setFlightNo(String flightNo) {
	this.flightNo = flightNo;
}
public String getBookingId() {
	return bookingId;
}
public void setBookingId(String bookingId) {
	this.bookingId = bookingId;
}
public String getCustEmail() {
	return custEmail;
}
public void setCustEmail(String custEmail) {
	this.custEmail = custEmail;
}
public int getNoOfPassengers() {
	return noOfPassengers;
}
public void setNoOfPassengers(int noOfPassengers) {
	this.noOfPassengers = noOfPassengers;
}
public String getClassType() {
	return classType;
}
public void setClassType(String classType) {
	this.classType = classType;
}
public double getTotalFare() {
	return totalFare;
}
public void setTotalFare(double totalFare) {
	this.totalFare = totalFare;
}
public String getSeatNumbers() {
	return seatNumbers;
}
public void setSeatNumbers(String seatNum) {
	this.seatNumbers = seatNum;
}
public String getCreditCardInfo() {
	return creditCardInfo;
}
public void setCreditCardInfo(String creditCardInfo) {
	this.creditCardInfo = creditCardInfo;
}
public String getArrCity() {
	return arrCity;
}
public void setArrCity(String arrCity) {
	this.arrCity = arrCity;
}
public String getDepCity() {
	return depCity;
}
public void setDepCity(String depCity) {
	this.depCity = depCity;
}

}
