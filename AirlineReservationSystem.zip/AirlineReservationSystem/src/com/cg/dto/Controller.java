package com.cg.dto;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ars.bean.FlightInformation;
import com.ars.exception.AirlineException;
import com.ars.service.AirlineServiceImpl;
import com.ars.service.IAirlineService;

/**
 * Servlet implementation class Controller
 */
@WebServlet("/Controller")
public class Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option=request.getParameter("action");
		IAirlineService airServ=new AirlineServiceImpl();
		switch(option)
		{
		case "modify":
			try{
			String choice=request.getParameter("modify");
			String val=request.getParameter("change");
			String flightNum=request.getParameter("flightnum");
			if(choice.equals("change source"))
			{
				System.out.println("In"+choice);
				String c="dep_city";
			airServ.adminModify(c,val,flightNum);
			}
			else if(choice.equals("change destination"))
			{
				System.out.println("In"+choice);
				String c="arr_city";
				airServ.adminModify(c,val,flightNum);
			}
			else if(choice.equals("change flightnum"))
			{
				System.out.println("In"+choice);
				String c="flightno";
				airServ.adminModify(c,val,flightNum);
			}
			else if(choice.equals("change firstseatsfare"))
			{
				System.out.println("In"+choice);
				String c="firstseatfare";
				airServ.adminModify(c,val,flightNum);
			}
			else if(choice.equals("change bussseatsfare"))
			{
				System.out.println("In"+choice);
				String c="bussseatsfare";
				airServ.adminModify(c,val,flightNum);
			}
			else if(choice.equals("change dep date"))
			{
				System.out.println("In"+choice);
				String c="dep_date";
				airServ.adminModify(c,val,flightNum);
			}
			else if(choice.equals("change dep time"))
			{
				System.out.println("In"+choice);
				String c="dep_time";
				airServ.adminModify(c,val,flightNum);
			}
				
			}
			catch(AirlineException e)
			{
				
			}
		}
	}

}
