package com.ars.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.exception.AirlineException;
import com.ars.util.DBConnection;

public class AirlineDaoImpl implements IAirlineDao {
 int i;
	@Override
	public boolean verifyUser(String uName, String password) throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try{
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.VALIDATEUSER);
			pst.setString(1,uName);
			pst.setString(2,password);
			rs=pst.executeQuery();
			rs.next();
			if(rs.getInt(1)>0)
			{
				return false;
			}
			else
				return true;
		}
		catch(SQLException se)
		{
			throw new AirlineException("Database Connection Problem.");
		}
		finally
		{
			try{
				rs.close();
				pst.close();
				conn.close();
			}
			catch(SQLException se)
			{
				throw new AirlineException("Database Connection closing Problem.");
			}
		}
	}

	@Override
	public void addUserDetails(Users user) throws AirlineException {
		Connection conn;
		try {
			conn = DBConnection.getInstance().getConnection();
		java.sql.Statement statement=conn.createStatement();
		ResultSet result=null;
		PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.INSERTQUERY);
		preparedStatement.setString(1,user.getuName());
		preparedStatement.setString(2,user.getPassword());
		preparedStatement.setString(3,user.getRole());
		preparedStatement.setString(4,user.getEmail());
		preparedStatement.executeQuery();
		} catch (SQLException e) {
			throw new AirlineException("DB Connetcion Problem");
		}
		
	}
	public String getRole(Users user) throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try{
			conn=DBConnection.getInstance().getConnection();
	pst=conn.prepareStatement(IQueryMapper.GETROLE);
	pst.setString(1,user.getuName());
	pst.setString(2,user.getPassword());
	rs=pst.executeQuery();
	rs.next();
	return rs.getString(1);
}	catch(SQLException se)
		{
	throw new AirlineException("Database Connection closing Problem.");
}
		
	}

	@Override
	public List<FlightInformation> getFlightInfo(FlightInformation flight) throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int count=0;
		try{
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.GETFLIGHTINFO);
			pst.setString(1,flight.getDepCity());
			pst.setString(2,flight.getArrCity());
			rs=pst.executeQuery();
			List<FlightInformation> airList=new ArrayList();
			while(rs.next())
			{
				flight.setFlightNo(rs.getString(1));
				flight.setAirline(rs.getString(2));
				flight.setDepDate(rs.getDate(3));
				flight.setArrDate(rs.getDate(4));
				flight.setDepTime(rs.getString(5));
				flight.setArrTime(rs.getString(6));
				flight.setFirstSeats(rs.getInt(7));
				flight.setFirstSeatFare(rs.getDouble(8));
				flight.setBussSeats(rs.getInt(9));
				flight.setBussSeatsFare(rs.getDouble(10));
				airList.add(flight);
				count++;
			}
			if(count>0)
				return airList;
			else
				return null;
		
	}
		catch(SQLException se)
		{
	throw new AirlineException("Database Connection closing Problem.");
}
		
}

	@Override
	public void updatePassword(String email,String password) throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int count=0;
		try{
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.UPDATEPASSWORD);
			pst.setString(1,password);
			pst.setString(2,email);
			pst.executeUpdate();
		}
		catch(SQLException se)
		{
			throw new AirlineException();
		}
	}

	@Override
	public void bookTickets(BookingInformation bookInfo) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet rs = null;
		int count=0;
		try{
			conn=DBConnection.getInstance().getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.BOOKTICKETS);
			preparedStatement.setString(1,bookInfo.getBookingId());
			preparedStatement.setString(2,bookInfo.getCustEmail());
			preparedStatement.setInt(3,bookInfo.getNoOfPassengers());
			preparedStatement.setString(4,bookInfo.getClassType());
			preparedStatement.setDouble(5,bookInfo.getTotalFare());
			preparedStatement.setString(6,bookInfo.getSeatNumbers());
			preparedStatement.setString(7,bookInfo.getCreditCardInfo());
			preparedStatement.setString(8,bookInfo.getDepCity());
			preparedStatement.setString(9,bookInfo.getArrCity());	
			preparedStatement.executeUpdate();
			
			updateFlightInfo(bookInfo.getNoOfPassengers(),bookInfo.getClassType());
			if(bookInfo.getClassType().equals("firstClass"))
			{
				preparedStatement =conn.prepareStatement(IQueryMapper.AvailFirstSeats);
				preparedStatement.executeUpdate();
				
			}
			else
			{
				preparedStatement =conn.prepareStatement(IQueryMapper.AvailBussSeats);
				preparedStatement.executeUpdate();
				
			}
			
	}
		catch(SQLException e)
		{
			throw new AirlineException();
		}
}

	private void updateFlightInfo(int noOfPassengers, String classType) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet rs = null;
		int count=0;
		try{
			conn=DBConnection.getInstance().getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.UPDATEFLIGHTINFO);
			
		}
			catch(SQLException e)
		{
				
		}
	}

	@Override
	public List<Integer> viewFlightOcuupancy(FlightInformation f) throws AirlineException {

		//StringBuilder s= new StringBuilder("");
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		int firstSeats=0,bussSeats=0,avlbleFrstSeats=0,avlbleBussSeats=0;
		int AvlFreeSeats=0;
		int totalSeats=0;
		int TotalfreeSeats=0;
		List<Integer> viewOccupancy=new ArrayList<Integer>();
		try{
			System.out.println("flghtno"+f.getFlightNo());
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.ViewFlightOccupancy);
			System.out.println("success");
			pst.setString(1,f.getFlightNo());
			rs = pst.executeQuery();
			if(rs.next())
			{
				firstSeats =rs.getInt(1);
				avlbleFrstSeats=rs.getInt(2);
				bussSeats =rs.getInt(3);
				avlbleBussSeats = rs.getInt(4);
				AvlFreeSeats =rs.getInt(2) + rs.getInt(4);
				
				
				totalSeats = rs.getInt(1) + rs.getInt(3);
				TotalfreeSeats= totalSeats-AvlFreeSeats;
				
				System.out.println("updated");
			}
			viewOccupancy.add(firstSeats);
			viewOccupancy.add(avlbleFrstSeats);
			viewOccupancy.add(bussSeats);
			viewOccupancy.add(avlbleBussSeats);
			viewOccupancy.add(totalSeats);
			viewOccupancy.add(TotalfreeSeats);
			
			
	
			
	}
		catch(SQLException e)
		{
			throw new AirlineException();
		}
		
return viewOccupancy;
}

	@Override
	public List<BookingInformation> getPassengerList(BookingInformation b)
			throws AirlineException {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		List<BookingInformation> passengerList=new ArrayList<BookingInformation>();
		try
		{
			System.out.println("flghtno"+b.getFlightNo());
			conn=DBConnection.getInstance().getConnection();
			pst=conn.prepareStatement(IQueryMapper.GETPASSENGERLIST);
			System.out.println("success");
			pst.setString(1,b.getFlightNo());
			rs = pst.executeQuery();
			while(rs.next())
			{
				BookingInformation book = new BookingInformation();
			book.setBookingId(rs.getString(1));
			book.setClassType(rs.getString(2));
			book.setSeatNumbers(rs.getString(3));
			passengerList.add(book);
			}
		}
		catch(SQLException e)
		{
			throw new AirlineException();	
		}
		return passengerList;
	}
	
}