package com.ars.pi;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.ars.bean.BookingInformation;
import com.ars.bean.FlightInformation;
import com.ars.bean.Users;
import com.ars.dao.AirlineDaoImpl;
import com.ars.dao.IAirlineDao;
import com.ars.exception.AirlineException;
import com.ars.service.AirlineServiceImpl;
import com.ars.service.IAirlineService;

public class AirlineMain {

	private static IAirlineService is;
	public static void main(String[] args) {
			int choice,coun=0;
			String uName,password,email,pass;
			IAirlineService is=new AirlineServiceImpl();
			Users user=null;
			try{
			Scanner scan=new Scanner(System.in);
			while(true)
			{
			System.out.println("Choose from below options:");
			System.out.println("1.Register\n2.Login\n3.Exit");
			choice=scan.nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("Please enter the details to complete registration:");
				do{
				System.out.println("UserName:");
				 uName=scan.next();
				}
				while(is.isValidName(uName));
				do{
				System.out.println("Password:");
				password=scan.next();
				}while(is.isValidPassword(password));
				do{
				System.out.println("E-mail:");
				email=scan.next();
				}while(is.isValidEmail(email));
				user=new Users();
				user.setRole("user");
				user.setuName(uName);
				user.setPassword(password);
				user.setEmail(email);
				is.addUserDetails(user);
				break;
			case 2:
				System.out.println("Please enter your login credentials:");
				do{
					user=new Users();
					System.out.println("UserName:");
					uName=scan.next();
					System.out.println("Password:");
					password=scan.next();
					coun++;
					if(coun==3)
					{
						System.out.println("You Need to Reset your password.");
						System.out.println("Enter your email ID");
						email=scan.next();
						System.out.println("Enter new password to login");
						pass=scan.next();
						is.isValidPassword(pass);
						is.updatePassword(email,pass);
						coun=0;
					}	
				}while(is.verifyUser(uName,password));
				user.setuName(uName);
				user.setPassword(password);
				if(is.getRole(user).equals("user"))
					getAirlines(user);	
			case 3:
				System.exit(0);
			}
		}
	}
			catch(AirlineException ae)
			{
				System.out.println("hello");
				System.err.println("Error Occured"+ae.getMessage());
				main(args);
			}
			
	}

	private static void getAirlines(Users user) throws AirlineException {
		Scanner scan=new Scanner(System.in);
		int choice;
		List<FlightInformation> airList;
		IAirlineService is = null;
		BookingInformation bookInfo=null;
		System.out.println("Welcome to Capgemini Airlines.");
		System.out.println("Please choose from below options:");
		System.out.println("1)Book Ticket\n2)View Ticket Info\n3)Cancel Booking");
		choice=scan.nextInt();
		switch(choice)
		{
		case 1:
		System.out.println("Please Enter your Source city:");
		String depCity=scan.next();
		System.out.println("Please Enter your destination city:");
		String arrCity=scan.next();
		is=new AirlineServiceImpl();
		FlightInformation flightinfo= new FlightInformation();
		flightinfo.setDepCity(depCity);
		flightinfo.setArrCity(arrCity);
		airList=is.getFlightInfo(flightinfo);
		if (airList != null) {
			Iterator<FlightInformation> i = airList.iterator();
			while (i.hasNext()) {
				FlightInformation flight=i.next();
				System.out.println(flight.getAirline());
			}
		}
	/*	bookTickets(is);*/
		/*Scanner scan=new Scanner(System.in);*/
		System.out.println("Enter flightno to book ticket");
		String flightNum=scan.next();
		System.out.println("Choose the class type from the following:");
		System.out.println("1)Bussiness Class 2)First Class");
		int type=scan.nextInt();
		System.out.println("Enter no of tickets:");
		int noofTickets=scan.nextInt();
		System.out.println("Enter your email id:");
		String email=scan.next();
		System.out.println("Enter your creditCard info");
		String card=scan.next();
	    bookInfo=new BookingInformation();
		bookInfo.setFlightNo(flightNum);
		if(type==1)
			bookInfo.setClassType("Bussiness");
		else
			bookInfo.setClassType("First");;
		bookInfo.setNoOfPassengers(noofTickets);
		bookInfo.setArrCity(arrCity);
		bookInfo.setDepCity(depCity);
		bookInfo.setCreditCardInfo(card);
		bookInfo.setCustEmail(email);
		int booking=is.bookTicket(bookInfo);
		System.out.println("Your booking id:"+booking);
		
		break;
		case 2:
			System.out.println("Enter booking Id to view details:");
			String bookingId=scan.next();
			is=new AirlineServiceImpl();
			bookInfo=is.viewFlightDetails(bookingId);
			if(bookInfo!=null)
			{
			bookInfo.setBookingId(bookingId);
			System.out.println("Your booking details are:");
			System.out.println("BookingId:"+bookInfo.getBookingId()+"\nCustomer Email:"+bookInfo.getCustEmail()+"\nno of passengers:"+bookInfo.getNoOfPassengers()+"\nClass Type:"+bookInfo.getClassType()+"\nTotal Fare:"+bookInfo.getTotalFare()+"\nSeat Numbers:"+bookInfo.getSeatNumbers()+"\nCredit Card info"+bookInfo.getCreditCardInfo()+"\nDeparture City:"+bookInfo.getDepCity()+"\nArrival City"+bookInfo.getArrCity());
			}
			break;
		case 3:
			System.out.println("Enter booking Id for cancelling ticket(s)");
			bookingId=scan.next();
			System.out.println("Are you sure you want to book tickets?");
			System.out.println("Enter 1)to continue 2)exit");
			int ch=scan.nextInt();
			if(ch==1)
			{
				is=new AirlineServiceImpl();
				int count=is.cancelBooking(bookingId);
				if(count==1)
				{
					System.out.println("You have cancelled the flight booking with booking Id:"+bookingId);
				}
				else
				{
					System.out.println("Your Booking doesn't exists");
				}
			}
			else
			{
				System.exit(0);
			}
			
			
		}
		
	}
	public static void bookTickets(IAirlineService is) throws AirlineException
	{
		
	}
}
