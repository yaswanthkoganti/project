package com.ars.bean;

public class Airport {

}
