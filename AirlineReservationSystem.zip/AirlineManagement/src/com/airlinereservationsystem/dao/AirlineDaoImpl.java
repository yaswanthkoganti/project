package com.airlinereservationsystem.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.airlinereservationsystem.bean.Airport;
import com.airlinereservationsystem.bean.BookingInformation;
import com.airlinereservationsystem.bean.FlightInformation;
import com.airlinereservationsystem.bean.Users;
import com.airlinereservationsystem.exception.AirlineException;
import com.airlinereservationsystem.util.DBConnection;

public class AirlineDaoImpl implements IAirlineDao {

	@Override
	public boolean verifyUser(String uName, String password) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		try{
			
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.VALIDATEUSER);
			preparedStatement.setString(1,uName);
			preparedStatement.setString(2,password);
			result=preparedStatement.executeQuery();
			result.next();
			if(result.getInt(1)>0)
			{
				return true;
			}
			else
				return false;
		}
		catch(SQLException se)
		{
			System.out.println("hello");
			throw new AirlineException("Database Connection Problem.");
		}
		/*finally
		{
			try{
				result.close();
				preparedStatement.close();
				conn.close();
			}
			catch(SQLException se)
			{
				throw new AirlineException("Database Connection closing Problem.");
			}
		}*/
	}

	@Override
	public void addUserDetails(Users user) throws AirlineException {
		Connection conn;
		try {
			conn = DBConnection.getConnection();
		java.sql.Statement statement=conn.createStatement();
		ResultSet result=null;
		PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.INSERTQUERY);
		preparedStatement.setString(1,user.getuName());
		preparedStatement.setString(2,user.getPassword());
		preparedStatement.setString(3,user.getRole());
		preparedStatement.setString(4,user.getEmail());
		preparedStatement.executeQuery();
		} catch (SQLException e) {
			throw new AirlineException("DB Connetcion Problem");
		}
		
	}
	public String getRole(Users user) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		try{
			conn=DBConnection.getConnection();
	preparedStatement=conn.prepareStatement(IQueryMapper.GETROLE);
	preparedStatement.setString(1,user.getuName());
	preparedStatement.setString(2,user.getPassword());
	result=preparedStatement.executeQuery();
	result.next();
	return result.getString(1);
}	catch(SQLException se)
		{
	throw new AirlineException("Database Connection closing Problem.");
}
		
	}

	@Override
	public List<FlightInformation> getFlightInfo(FlightInformation fligh) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		List<FlightInformation> airList=null;
		int count=0;
		try{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.GETFLIGHTINFO);
			preparedStatement.setString(1,fligh.getDepCity());
			preparedStatement.setString(2,fligh.getArrCity());
			result=preparedStatement.executeQuery();
			airList=new ArrayList<FlightInformation>();
			while(result.next())
			{
				FlightInformation flight=new FlightInformation();
				flight.setFlightNo(result.getString(1));
				flight.setAirline(result.getString(2));
				flight.setDepCity(result.getString(3));
				flight.setArrCity(result.getString(4));
				flight.setDepDate(result.getDate(5));
				flight.setArrDate(result.getDate(6));
				flight.setDepTime(result.getString(7));
				flight.setArrTime(result.getString(8));
				flight.setFirstSeats(result.getInt(9));
				flight.setFirstSeatFare(result.getDouble(10));
				flight.setBussSeats(result.getInt(11));
				flight.setBussSeatsFare(result.getDouble(12));
				flight.setBussAvail(result.getInt(13));
				flight.setFirstAvail(result.getInt(14));
				airList.add(flight);
				count++;
			}
			if(count>0)
				return airList;
			else
				return null;
		
	}
		catch(SQLException se)
		{
	throw new AirlineException("Database Connection closing Problem.");
}
		
}

	@Override
	public void updatePassword(String email,String password) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		int count=0;
		try{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.UPDATEPASSWORD);
			preparedStatement.setString(1,password);
			preparedStatement.setString(2,email);
			preparedStatement.executeUpdate();
		}
		catch(SQLException se)
		{
			throw new AirlineException();
		}
	}

	@Override
	public String bookTickets(BookingInformation bookInfo) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet result = null;
		String bookingId;
		try{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.GENERATESEQ);
			result=preparedStatement.executeQuery();
			result.next();
			bookingId=result.getString(1);
			preparedStatement=conn.prepareStatement(IQueryMapper.BOOKTICKETS);
			preparedStatement.setString(1,bookingId);
			preparedStatement.setString(2,bookInfo.getCustEmail());
			preparedStatement.setInt(3,bookInfo.getNoOfPassengers());
			preparedStatement.setString(4,bookInfo.getClassType());
			preparedStatement.setDouble(5,bookInfo.getTotalFare());
			preparedStatement.setString(6,bookInfo.getSeatNumbers().toString());
			preparedStatement.setString(7,bookInfo.getCreditCardInfo());
			preparedStatement.setString(8,bookInfo.getDepCity());
			preparedStatement.setString(9,bookInfo.getArrCity());
			preparedStatement.setString(10,bookInfo.getFlightNo());
			preparedStatement.executeUpdate();
			updateFlightInfo(bookInfo.getNoOfPassengers(),bookInfo.getClassType(),bookInfo.getFlightNo());
	}
		catch(SQLException e)
		{
			throw new AirlineException();
		}
		return bookingId;
}

	private void updateFlightInfo(int noOfPassengeresult, String classType,String flightNo) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet result = null;
		int count=0;
		try{
			conn=DBConnection.getConnection();
			if(classType.equals("Bussiness"))
			{
		
				preparedStatement=conn.prepareStatement(IQueryMapper.UPDATEFLIGHTINFOBUS);
				preparedStatement.setInt(1,noOfPassengeresult);
				preparedStatement.setString(2,flightNo); 
				preparedStatement.executeUpdate();
			}
			else
			{
				preparedStatement=conn.prepareStatement(IQueryMapper.UPDATEFLIGHTINFOFIRST);
				preparedStatement.setInt(1,noOfPassengeresult);
				preparedStatement.setString(2,flightNo); 
				preparedStatement.executeUpdate();
			}
			}
			catch(SQLException e)
		{
				
		}
	}

	@Override
	public BookingInformation viewFlightDetails(String bookingId) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet result = null;
		BookingInformation bookInfo=null;
		{
			System.out.println(bookingId);
			conn=DBConnection.getConnection();
			try {
				preparedStatement=conn.prepareStatement(IQueryMapper.VIEWBOOKINGDETAILS);
				preparedStatement.setString(1,bookingId);
				result=preparedStatement.executeQuery();
				while(result.next())
				{
					bookInfo=new BookingInformation();
					bookInfo.setBookingId(result.getString(1));
					bookInfo.setCustEmail(result.getString(2));
					bookInfo.setNoOfPassengers(result.getInt(3));
					bookInfo.setClassType(result.getString(4));
					bookInfo.setCreditCardInfo(result.getString(7));
					bookInfo.setArrCity(result.getString(9));
					bookInfo.setDepCity(result.getString(8));
					bookInfo.setTotalFare(result.getDouble(5));
					bookInfo.setSeatNumbers(result.getString(6));
					bookInfo.setFlightNo(result.getString(10));
				}
				
			} catch (SQLException e) {
				
				e.printStackTrace();
			}
		}
		return bookInfo;
	}

	@Override
	public int cancelBooking(String bookingId) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		int count=0;
		{
			conn=DBConnection.getConnection();
			try {
				preparedStatement=conn.prepareStatement(IQueryMapper.GETBOOKEDSEATS);
				preparedStatement.setString(1,bookingId);
				ResultSet result=preparedStatement.executeQuery();
				result.next();
				int noOfPassengers=result.getInt(1);
				String classTpe=result.getString(2);
				String flightNum=result.getString(3);
				preparedStatement=conn.prepareStatement(IQueryMapper.CANCELBOOKING);
				preparedStatement.setString(1,bookingId);
				count=preparedStatement.executeUpdate();
				if(count>0)
					updateSeats(noOfPassengers,classTpe,flightNum);
				else
					throw new AirlineException("Invalid Booking Id");
	}
			catch(SQLException e)
			{
				
			}
			return count;
	
}
	}
	

	private void updateSeats(int noOfPassengers,String classType,String flightNum) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet result = null;
		int count=0;
		try
		{
			conn=DBConnection.getConnection();
			if(classType.equals("Bussiness"))
			{
				System.out.println(noOfPassengers);
			preparedStatement=conn.prepareStatement(IQueryMapper.UPDATEBUSSSEATS);
			preparedStatement.setInt(1,noOfPassengers);
			preparedStatement.setString(2,flightNum);
			}
			else
			{
			preparedStatement=conn.prepareStatement(IQueryMapper.UPDATEFIRSTSEATS);
			preparedStatement.setInt(1,noOfPassengers);
			preparedStatement.setString(2,flightNum);
			}
			preparedStatement.executeUpdate();
			}catch(SQLException e)
		{
				
		}
		
	}

	@Override
	public void addFlight(FlightInformation flight) throws AirlineException{
		
		
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet result = null;
		int count=0;
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.INSERT);	
			
			//System.out.println("hii");
			preparedStatement.setString(1,flight.getFlightNo());
			preparedStatement.setString(2,flight.getAirline());
			preparedStatement.setString(3,flight.getDepCity());
			preparedStatement.setString(4,flight.getArrCity());
			preparedStatement.setDate(5,flight.getDepDate());
			preparedStatement.setDate(6,flight.getArrDate());
			preparedStatement.setString(7,flight.getDepTime());
			preparedStatement.setString(8,flight.getArrTime());
			preparedStatement.setInt(9,flight.getFirstSeats());
			preparedStatement.setDouble(10,flight.getFirstSeatFare());
			preparedStatement.setInt(11,flight.getBussSeats());
			preparedStatement.setDouble(12,flight.getBussSeatsFare());
			preparedStatement.setInt(13,flight.getBussSeats());
			preparedStatement.setInt(14,flight.getFirstSeats());
			
			//System.out.println("hgi");
			count=preparedStatement.executeUpdate();
			//System.out.println(count);
	        }
		catch(SQLException e)
		{
			throw new AirlineException();
		}
		
		
		
		
		
		
	}

	@Override
	public int deleteFlight(FlightInformation flight) throws AirlineException {
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet result = null;
		int count=0;
		try
		{   
			
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.DELETEFLIGHT);
			preparedStatement.setString(1, flight.getFlightNo());
		    count=preparedStatement.executeUpdate();
		    
		 
	        }
		catch(SQLException e)
		{
			throw new AirlineException();
		}
		
	return count;	
	}

	@Override
	public  int isValidFlightNum(String fnum) throws AirlineException {              // boolean is changed to int
		Connection conn = null;
		PreparedStatement preparedStatement= null;
		ResultSet result = null;
		int count=0;
		try
		{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.CHECKFLIGHT);
			preparedStatement.setString(1,fnum);
		    count=preparedStatement.executeUpdate();  
			
		
	     }
		catch(SQLException e)
		{
			throw new AirlineException();
		}
	return count;
	}
	@Override
	public List<FlightInformation> viewFlightOcuupancy(FlightInformation f) throws AirlineException {

		//StringBuilder s= new StringBuilder("");
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		int firesulttSeats=0,bussSeats=0,avlbleFresulttSeats=0,avlbleBussSeats=0;
		int AvlFreeSeats=0;
		int totalSeats=0;
		int TotalfreeSeats=0;
		List<FlightInformation> flightList=new ArrayList<FlightInformation>();
		try{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.ViewFlightOccupancy);
			preparedStatement.setString(1,f.getFlightNo());
			result = preparedStatement.executeQuery();
			flightList=new ArrayList<FlightInformation>();
			if(result.next())
			{
				FlightInformation flight=new FlightInformation();
				flight.setBussAvail(result.getInt(4));
				flight.setFirstAvail(result.getInt(2));
				flight.setFirstSeats(result.getInt(1));
				flight.setBussSeats(result.getInt(3));
				flightList.add(flight);
			}
	}
		catch(SQLException e)
		{
			throw new AirlineException();
		}
		
return flightList;
}
	@Override
	public List<FlightInformation> getFlightInfoDay(FlightInformation finfo) throws AirlineException { //changed from flight to fingo
		
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		int count=0;
		try{
			conn=DBConnection.getConnection();
			System.out.println(conn);
			preparedStatement=conn.prepareStatement(IQueryMapper.GETFLIGHTINFODAY);
			preparedStatement.setString(1,finfo.getArrCity());
			preparedStatement.setString(2,finfo.getDepDate().toString());
			List<FlightInformation> flightList=new ArrayList<FlightInformation>();   
			result=preparedStatement.executeQuery();
			while(result.next())
			{
			System.out.println(result.getString(1));
				FlightInformation flightnew=new FlightInformation();
				flightnew.setFlightNo(result.getString(1));
				flightnew.setAirline(result.getString(2));
				flightnew.setDepCity(result.getString(3));
				flightnew.setArrCity(result.getString(4));
				flightnew.setDepDate(result.getDate(5));
				flightnew.setArrDate(result.getDate(6));
				flightnew.setDepTime(result.getString(7));
				flightnew.setArrTime(result.getString(8));
				flightnew.setFirstSeats(result.getInt(9));
				flightnew.setFirstSeatFare(result.getDouble(10));
				flightnew.setBussSeats(result.getInt(11));
				flightnew.setBussSeatsFare(result.getDouble(12));
				flightnew.setFirstAvail(result.getInt(13));
				flightnew.setBussAvail(result.getInt(14));
				flightList.add(flightnew);          
				count++;
			}
			if(count>0)
				return flightList;             
			else
				return null;
		
	}
		catch(SQLException se)
		{
	throw new AirlineException("Database Connection closing Problem.");
}
		
}




@Override
	public List<BookingInformation> getFlightBook(BookingInformation bookinfo) throws AirlineException {
		
		Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		int count=0;
		try{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.BOOKDETAILS);
			
			preparedStatement.setString(1,bookinfo.getFlightNo());
			
			result=preparedStatement.executeQuery();
			List<BookingInformation> bookList=new ArrayList();
			while(result.next())
			{
				BookingInformation book=new BookingInformation();
		        book.setBookingId(result.getString(1));
				book.setCustEmail(result.getString(2));
				book.setNoOfPassengers(result.getInt(3));
				book.setClassType(result.getString(4));
				book.setTotalFare(result.getDouble(5));
				book.setSeatNumbers(result.getString(6));
				book.setCreditCardInfo(result.getString(7));
				book.setDepCity(result.getString(8));
				book.setArrCity(result.getString(9));
				book.setFlightNo(result.getString(10));
				bookList.add(book);
				count++;
			}
			if(count>0)
				return bookList;
			else
				return null;
		
	       }
		catch(SQLException se)
		{
	         throw new AirlineException("Database Connection closing Problem.");
        }
	}

@Override
public FlightInformation getFlightDetails(String fNo) throws AirlineException {
	 Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		FlightInformation flightnew=new FlightInformation();
		try{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.GETFLIGHTDETAILS);
			preparedStatement.setString(1, fNo);
			result=preparedStatement.executeQuery();
			while(result.next())
			{
				
				flightnew.setFlightNo(result.getString(1));
				flightnew.setAirline(result.getString(2));
				flightnew.setDepCity(result.getString(3));
				flightnew.setArrCity(result.getString(4));
				flightnew.setDepDate(result.getDate(5));
				flightnew.setArrDate(result.getDate(6));
				flightnew.setDepTime(result.getString(7));
				flightnew.setArrTime(result.getString(8));
				flightnew.setFirstSeats(result.getInt(9));
				flightnew.setFirstSeatFare(result.getDouble(10));
				flightnew.setBussSeats(result.getInt(11));
				flightnew.setBussSeatsFare(result.getDouble(12));
				flightnew.setFirstAvail(result.getInt(13));
				flightnew.setBussAvail(result.getInt(14));
				
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return flightnew;
}

@Override
public List<Airport> getAirport(String city) throws AirlineException {
	 Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		FlightInformation flightnew=new FlightInformation();
		List<Airport> airPortList=null;
		try{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.GETAIRPORTLIST);
			preparedStatement.setString(1,city);
			result=preparedStatement.executeQuery();
			airPortList=new ArrayList<Airport>();
			while(result.next())
			{
				com.airlinereservationsystem.bean.Airport airport=new com.airlinereservationsystem.bean.Airport();
				airport.setAirportName(result.getString(1));
				airport.setAbbreviation(result.getString(2));
				airport.setCity(result.getString(3));
				System.out.println(airport.getCity());
				airPortList.add(airport);
			}
		}
		catch(SQLException e)
		{
			
		}
			
	return airPortList;
}	
@Override
public List<BookingInformation> getPassengerList(BookingInformation b)
		throws AirlineException {
	Connection conn = null;
	PreparedStatement pst = null;
	ResultSet rs = null;
	List<BookingInformation> passengerList=new ArrayList<BookingInformation>();
	try
	{
		conn=DBConnection.getConnection();
		pst=conn.prepareStatement(IQueryMapper.GETPASSENGERLIST);
		pst.setString(1,b.getFlightNo());
		rs = pst.executeQuery();
		while(rs.next())
		{
			BookingInformation book = new BookingInformation();
			System.out.println(rs.getString(1));
		book.setBookingId(rs.getString(1));
		book.setDepCity(rs.getString(2));
		book.setArrCity(rs.getString(3));
		book.setClassType(rs.getString(4));
		book.setNoOfPassengers(rs.getInt(5));
		book.setSeatNumbers(rs.getString(6));
		book.setTotalFare(rs.getDouble(7));
		passengerList.add(book);
		}
	}
	catch(SQLException e)
	{
		throw new AirlineException();	
	}
	return passengerList;
}


@Override
public void adminModify(String c, String val,String flightnum) throws AirlineException {

	Connection conn = null;
	int count=0;
	try{
		conn=DBConnection.getConnection();
		PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.dynamicQuery(c));
		if(c.equals("firstseatsfare"))
		{
			int value=Integer.parseInt(val);
			preparedStatement.setInt(1,value);
		}	
		else if(c.equals("bussseatsfare"))
		{
			int value=Integer.parseInt(val);
			preparedStatement.setInt(1,value);
		}
		else if(c.equals("dep_date"))
		{
			SimpleDateFormat sdf1 = new SimpleDateFormat("dd/MM/yyyy");
			java.util.Date dateut = sdf1.parse(val);
			java.sql.Date value = new java.sql.Date(dateut.getTime()); 
			preparedStatement.setDate(1,value);
		}
		else
		{
			String value=val;
			preparedStatement.setString(1,value);
		}
		preparedStatement.setString(2,flightnum);
		preparedStatement.executeUpdate();
		
	
}
	catch(SQLException e)
	{
		System.out.println("error"+e.getMessage());
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}



	
}
	/*
	 * Connection conn = null;
		PreparedStatement preparedStatement = null;
		ResultSet result = null;
		int count=0;
		try{
			conn=DBConnection.getConnection();
			preparedStatement=conn.prepareStatement(IQueryMapper.GETFLIGHTINFODAY);
			preparedStatement.setString(1,finfo.getArrCity());
			preparedStatement.setString(2,finfo.getDepDate().toString());
			List<FlightInformation> flightList=new ArrayList();   
			result=preparedStatement.executeQuery();
			while(result.next())
			{
				FlightInformation flightnew=new FlightInformation();
				flightnew.setFlightNo(result.getString(1));
				flightnew.setAirline(result.getString(2));
				flightnew.setDepCity(result.getString(3));
				flightnew.setArrCity(result.getString(4));
				flightnew.setDepDate(result.getDate(5));
				flightnew.setArrDate(result.getDate(6));
				flightnew.setDepTime(result.getString(7));
				flightnew.setArrTime(result.getString(8));
				flightnew.setFiresulttSeats(result.getInt(9));
				flightnew.setFiresulttSeatFare(result.getDouble(10));
				flightnew.setBussSeats(result.getInt(11));
				flightnew.setBussSeatsFare(result.getDouble(12));
				flightnew.setFiresulttAvail(result.getInt(13));
				flightnew.setBussAvail(result.getInt(14));
				flightList.add(flightnew);   
	 */

@Override
public List<FlightInformation> viewByCity(String depCity, String arrCity) throws AirlineException {
	Connection conn = null;
	List<FlightInformation> flightList=null;
	try{
		conn=DBConnection.getConnection();
		PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.VIEWBYCITY);
		preparedStatement.setString(1,depCity);
		preparedStatement.setString(2,arrCity);
		System.out.println(depCity);
		ResultSet result=preparedStatement.executeQuery();
		flightList=new ArrayList<FlightInformation>();
		while(result.next())
		{
			System.out.println("hello");
			FlightInformation flight=new FlightInformation();
			flight.setBussAvail(result.getInt(4));
			flight.setFirstAvail(result.getInt(2));
			flight.setFirstSeats(result.getInt(1));
			flight.setBussSeats(result.getInt(3));
			flight.setFlightNo(result.getString(5));
			flightList.add(flight);
		}
	
}catch(SQLException e)
	{
	
}
	return flightList;
}

@Override
public List<String> getDepList() throws AirlineException {
	Connection conn = null;
	List<String> arrList=null;
	try{
		conn=DBConnection.getConnection();
		PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.GETDEPLIST);
		ResultSet result=preparedStatement.executeQuery();
		arrList=new ArrayList<String>();
		while(result.next())
		{
			arrList.add(result.getString(1));
		}
	}
	catch(SQLException e)
	{
		
	}
	return arrList;
		
}

@Override
public List<String> getArrList() throws AirlineException {
	Connection conn = null;
	List<String> arrList=null;
	try{
		conn=DBConnection.getConnection();
		PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.GETARRLIST);
		ResultSet result=preparedStatement.executeQuery();
		arrList=new ArrayList<String>();
		while(result.next())
		{
			arrList.add(result.getString(1));
		}
	}
	catch(SQLException e)
	{
		
	}
	return arrList;
}
	
}