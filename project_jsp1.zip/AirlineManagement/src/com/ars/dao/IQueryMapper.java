package com.ars.dao;

public interface IQueryMapper {

	public static final String VALIDATEUSER = "Select count(*) from users WHERE username=? AND password=?";
	public static final String INSERTQUERY = "Insert into users values(?,?,?,?)";
	public static final String GETROLE = "Select role from users where username=? AND password=? ";
	public static final String GETFLIGHTINFO = "SELECT * from flightinformation where dep_city=? AND arr_city=? AND (AVAIL_BUSSSEATS>0 OR AVAIL_FIRSTSEATS>0)";
	public static final String UPDATEPASSWORD = "UPDATE users SET password=? where email=?";
	public static final String BOOKTICKETS = "INSERT INTO bookinginformation VALUES(?,?,?,?,?,?,?,?,?,?)";
	public static final String UPDATEFLIGHTINFOBUS = "UPDATE flightinformation SET avail_bussseats=avail_bussseats-? where flightno=?";
	public static final String UPDATEFLIGHTINFOFIRST = "UPDATE flightinformation SET avail_firstseats=avail_firstseats-? where flightno=?";
	public static final String GENERATESEQ = "SELECT booking_seq_id.nextval from dual";
	public static final String VIEWBOOKINGDETAILS = "SELECT * FROM bookinginformation where booking_id=?";
	public static final String CANCELBOOKING = "DELETE FROM bookinginformation where booking_id=?";
	public static final String INSERT = "INSERT INTO flightinformation VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	public static final String DELETEFLIGHT = "DELETE FROM flightinformation where flightno=?";
	public static final String CHECKFLIGHT = "SELECT COUNT(*) FROM flightinformation where flightno=?";
	public static final String ViewFlightOccupancy = "select firstseats,avail_firstseats,Bussseats,avail_bussseats from flightinformation where flightNo=?";
	public static final String GETFLIGHTINFODAY = "SELECT * FROM flightinformation WHERE arr_city=? AND TO_CHAR(dep_date,'yyyy-MM-dd')=? ";
	public static final String BOOKDETAILS = "SELECT * FROM bookinginformation where flightno=?";
	public static final String GETFLIGHTDETAILS="SELECT * FROM flightinformation where flightNo=?";



}
