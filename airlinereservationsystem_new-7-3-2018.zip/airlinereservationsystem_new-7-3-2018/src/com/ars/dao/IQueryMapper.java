package com.ars.dao;

public interface IQueryMapper {

	public static final String VALIDATEUSER = "SELECT count(*) FROM users WHERE username=? AND password=?";
	public static final String INSERTQUERY = "Insert into users values(?,?,?,?)";
	public static final String GETROLE = "SELECT role FROM users where username=? AND password=?";
	public static final String GETFLIGHTINFO = "SELECT * FROM flightinformation where dep_city=? AND arr_city=?";
	public static final String UPDATEPASSWORD = "UPDATE users SET password=? where email=?";
	public static final String BOOKTICKETS = "INSERT INTO bookinformation VALUES(?,?,?,?,?,?,?,?,?)";
	public static final String UPDATEFLIGHTINFO = "UPDATE flightinformation SET ";
	public static final String AvailFirstSeats ="UPDATE flightInformation SET avail_firstseats=firstseats-1";
	public static final String AvailBussSeats ="UPDATE flightInformation SET avail_bussseats=Bussseats-1";
	public static final String ViewFlightOccupancy = "select firstseats,avail_firstseats,Bussseats,avail_bussseats FROM flightinformation where flightNo=?";
	public static final String GETPASSENGERLIST ="SELECT booking_id,class_type,seat_number FROM bookinginformation WHERE flightno=?";
}
